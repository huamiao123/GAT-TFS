# EXPERIMENT_ISSUES — current controlled GCN-extra experiments

Prior experiment entries removed by explicit user request. The retained run snapshots are immutable; older package hashes in current publication events describe superseded current-run bundles. See the cleaned archive manifest for active artifacts.

## paper-method-build-20261004-123445

```json
{
  "id": "paper-method-build-20261004-123445",
  "kind": "paper_method_build",
  "status": "PASS",
  "exit_status": 0,
  "evidence": "/home/huangjianqiang_group/hdacp1/data/wzh/GCN-extra/runs/paper-method-build-20261004-123445",
  "paper_eligible": false,
  "issues": "Controls fixed in PAPER_METHODS_PROTOCOL_20261004.md; no numerical gate changes allowed",
  "next": "Shared smoke before exclusive controlled comparisons",
  "date": "2026-10-04T04:34:55.032222+00:00"
}
```

## paper-method-submit-smoke-20261004-123733

```json
{
  "id": "paper-method-submit-smoke-20261004-123733",
  "kind": "controlled_paper_method_submission",
  "status": "SUBMITTED",
  "job_id": "10864873",
  "mode": "smoke",
  "evidence": "/home/huangjianqiang_group/hdacp1/data/wzh/GCN-extra/runs/paper-method-submit-smoke-20261004-123733",
  "paper_eligible": false,
  "next": "Correctness before formal",
  "date": "2026-10-04T04:37:34.705347+00:00"
}
```

## paper-method-smoke-10864873

```json
{
  "id": "paper-method-smoke-10864873",
  "kind": "controlled_paper_method_comparison",
  "status": "PASS",
  "exit_status": 0,
  "job_id": "10864873",
  "node": "qhcn049",
  "build": "/home/huangjianqiang_group/hdacp1/data/wzh/GCN-extra/runs/paper-method-build-20261004-123445",
  "evidence": "/home/huangjianqiang_group/hdacp1/data/wzh/GCN-extra/runs/paper-method-smoke-10864873",
  "completion": {
    "passed": 2,
    "failed": 0,
    "checks": 120,
    "mode": "smoke"
  },
  "paper_eligible": false,
  "issues": "Same graph/tensors/thread binding/NUMA policy/output precision/timing; original source anchor and rotated method order; frozen numerical gates",
  "next": "Reconcile all three disjoint graph batches against raw evidence",
  "date": "2026-10-04T04:37:42.137819+00:00"
}
```

## paper-method-submit-high-20261004-123850

```json
{
  "id": "paper-method-submit-high-20261004-123850",
  "kind": "controlled_paper_method_submission",
  "status": "SUBMITTED",
  "job_id": "10864874",
  "mode": "high",
  "evidence": "/home/huangjianqiang_group/hdacp1/data/wzh/GCN-extra/runs/paper-method-submit-high-20261004-123850",
  "paper_eligible": false,
  "next": "Within-graph same-process controlled comparison; never mix nodes in speedup",
  "date": "2026-10-04T04:38:51.660421+00:00"
}
```

## paper-method-submit-medium-20261004-123855

```json
{
  "id": "paper-method-submit-medium-20261004-123855",
  "kind": "controlled_paper_method_submission",
  "status": "SUBMITTED",
  "job_id": "10864875",
  "mode": "medium",
  "evidence": "/home/huangjianqiang_group/hdacp1/data/wzh/GCN-extra/runs/paper-method-submit-medium-20261004-123855",
  "paper_eligible": false,
  "next": "Within-graph same-process controlled comparison; never mix nodes in speedup",
  "date": "2026-10-04T04:38:57.167762+00:00"
}
```

## paper-method-submit-low-20261004-123901

```json
{
  "id": "paper-method-submit-low-20261004-123901",
  "kind": "controlled_paper_method_submission",
  "status": "SUBMITTED",
  "job_id": "10864876",
  "mode": "low",
  "evidence": "/home/huangjianqiang_group/hdacp1/data/wzh/GCN-extra/runs/paper-method-submit-low-20261004-123901",
  "paper_eligible": false,
  "next": "Within-graph same-process controlled comparison; never mix nodes in speedup",
  "date": "2026-10-04T04:39:02.443074+00:00"
}
```

## paper-method-high-10864874

```json
{
  "id": "paper-method-high-10864874",
  "kind": "controlled_paper_method_comparison",
  "status": "PASS",
  "exit_status": 0,
  "job_id": "10864874",
  "node": "qhcn818",
  "build": "/home/huangjianqiang_group/hdacp1/data/wzh/GCN-extra/runs/paper-method-build-20261004-123445",
  "evidence": "/home/huangjianqiang_group/hdacp1/data/wzh/GCN-extra/runs/paper-method-high-10864874",
  "completion": {
    "passed": 5,
    "failed": 0,
    "checks": 300,
    "mode": "high"
  },
  "paper_eligible": true,
  "issues": "Same graph/tensors/thread binding/NUMA policy/output precision/timing; original source anchor and rotated method order; frozen numerical gates",
  "next": "Reconcile all three disjoint graph batches against raw evidence",
  "date": "2026-10-04T04:55:35.275083+00:00"
}
```

## paper-method-medium-10864875

```json
{
  "id": "paper-method-medium-10864875",
  "kind": "controlled_paper_method_comparison",
  "status": "PASS",
  "exit_status": 0,
  "job_id": "10864875",
  "node": "qhcn817",
  "build": "/home/huangjianqiang_group/hdacp1/data/wzh/GCN-extra/runs/paper-method-build-20261004-123445",
  "evidence": "/home/huangjianqiang_group/hdacp1/data/wzh/GCN-extra/runs/paper-method-medium-10864875",
  "completion": {
    "passed": 5,
    "failed": 0,
    "checks": 300,
    "mode": "medium"
  },
  "paper_eligible": true,
  "issues": "Same graph/tensors/thread binding/NUMA policy/output precision/timing; original source anchor and rotated method order; frozen numerical gates",
  "next": "Reconcile all three disjoint graph batches against raw evidence",
  "date": "2026-10-04T04:55:50.627902+00:00"
}
```

## paper-method-low-10864876

```json
{
  "id": "paper-method-low-10864876",
  "kind": "controlled_paper_method_comparison",
  "status": "PASS",
  "exit_status": 0,
  "job_id": "10864876",
  "node": "qhcn818",
  "build": "/home/huangjianqiang_group/hdacp1/data/wzh/GCN-extra/runs/paper-method-build-20261004-123445",
  "evidence": "/home/huangjianqiang_group/hdacp1/data/wzh/GCN-extra/runs/paper-method-low-10864876",
  "completion": {
    "passed": 7,
    "failed": 0,
    "checks": 420,
    "mode": "low"
  },
  "paper_eligible": true,
  "issues": "Same graph/tensors/thread binding/NUMA policy/output precision/timing; original source anchor and rotated method order; frozen numerical gates",
  "next": "Reconcile all three disjoint graph batches against raw evidence",
  "date": "2026-10-04T05:03:34.569899+00:00"
}
```

## paper-method-reconciliation-20261004

```json
{
  "id": "paper-method-reconciliation-20261004",
  "kind": "controlled_paper_method_reconciliation",
  "status": "PASS",
  "report": "/home/huangjianqiang_group/hdacp1/data/wzh/GCN-extra/docs/PAPER_METHODS_RESULTS_20261004.md",
  "evidence": "/home/huangjianqiang_group/hdacp1/data/wzh/GCN-extra/runs/paper-method-reconciled-20261004",
  "summary": {
    "graphs": 17,
    "methods": 16,
    "candidate_methods": 14,
    "numerical_checks": 1020,
    "numerical_failures": 0,
    "measured_repetitions": 2720,
    "nodes": {
      "paper-method-high-10864874": "qhcn818",
      "paper-method-medium-10864875": "qhcn817",
      "paper-method-low-10864876": "qhcn818"
    },
    "same_binary_hashes": true,
    "primary_statistic": "median of five, same graph/process/buffers; corresponding original TFS/MKL medians",
    "fixed": [
      {
        "method": "b2_fast",
        "graphs": 17,
        "median_gmean_vs_tfs": 0.7285863197833305,
        "median_gmean_vs_mkl": 1.3810643114762338,
        "min_gmean_vs_tfs": 0.729950949469959,
        "wins_vs_tfs": 0,
        "wins_vs_mkl": 14
      },
      {
        "method": "b2_accurate",
        "graphs": 17,
        "median_gmean_vs_tfs": 0.5846698085894831,
        "median_gmean_vs_mkl": 1.1082648475759236,
        "min_gmean_vs_tfs": 0.5870799658335182,
        "wins_vs_tfs": 0,
        "wins_vs_mkl": 10
      },
      {
        "method": "b4_fast",
        "graphs": 17,
        "median_gmean_vs_tfs": 0.9381041940957733,
        "median_gmean_vs_mkl": 1.778213765113145,
        "min_gmean_vs_tfs": 0.9402015721230681,
        "wins_vs_tfs": 4,
        "wins_vs_mkl": 15
      },
      {
        "method": "b4_accurate",
        "graphs": 17,
        "median_gmean_vs_tfs": 0.8127004176159869,
        "median_gmean_vs_mkl": 1.5405059252622955,
        "min_gmean_vs_tfs": 0.8123747097562057,
        "wins_vs_tfs": 2,
        "wins_vs_mkl": 14
      },
      {
        "method": "b8_fast",
        "graphs": 17,
        "median_gmean_vs_tfs": 1.1103264515904865,
        "median_gmean_vs_mkl": 2.104667895542813,
        "min_gmean_vs_tfs": 1.1070459684564808,
        "wins_vs_tfs": 9,
        "wins_vs_mkl": 17
      },
      {
        "method": "b8_accurate",
        "graphs": 17,
        "median_gmean_vs_tfs": 1.0136172733180502,
        "median_gmean_vs_mkl": 1.921351806456795,
        "min_gmean_vs_tfs": 1.0129931339428484,
        "wins_vs_tfs": 7,
        "wins_vs_mkl": 16
      },
      {
        "method": "b16_fast",
        "graphs": 17,
        "median_gmean_vs_tfs": 1.2226753543235622,
        "median_gmean_vs_mkl": 2.317629703615613,
        "min_gmean_vs_tfs": 1.2200868880591302,
        "wins_vs_tfs": 10,
        "wins_vs_mkl": 17
      },
      {
        "method": "b16_accurate",
        "graphs": 17,
        "median_gmean_vs_tfs": 1.1481607022295304,
        "median_gmean_vs_mkl": 2.176384220555021,
        "min_gmean_vs_tfs": 1.1465153723509696,
        "wins_vs_tfs": 9,
        "wins_vs_mkl": 17
      },
      {
        "method": "b32_fast",
        "graphs": 17,
        "median_gmean_vs_tfs": 1.2797964001422986,
        "median_gmean_vs_mkl": 2.4259049150386263,
        "min_gmean_vs_tfs": 1.2781556736618351,
        "wins_vs_tfs": 11,
        "wins_vs_mkl": 17
      },
      {
        "method": "b32_accurate",
        "graphs": 17,
        "median_gmean_vs_tfs": 1.2263766070725375,
        "median_gmean_vs_mkl": 2.324645575229677,
        "min_gmean_vs_tfs": 1.225162452806029,
        "wins_vs_tfs": 10,
        "wins_vs_mkl": 17
      },
      {
        "method": "b64_fast",
        "graphs": 17,
        "median_gmean_vs_tfs": 1.3011897199830935,
        "median_gmean_vs_mkl": 2.4664568026240326,
        "min_gmean_vs_tfs": 1.301418260991466,
        "wins_vs_tfs": 11,
        "wins_vs_mkl": 17
      },
      {
        "method": "b64_accurate",
        "graphs": 17,
        "median_gmean_vs_tfs": 1.261220829948195,
        "median_gmean_vs_mkl": 2.3906941838406714,
        "min_gmean_vs_tfs": 1.260304386756196,
        "wins_vs_tfs": 11,
        "wins_vs_mkl": 17
      },
      {
        "method": "bfull_fast",
        "graphs": 17,
        "median_gmean_vs_tfs": 1.2513960779370457,
        "median_gmean_vs_mkl": 2.3720709761255754,
        "min_gmean_vs_tfs": 1.2525722184789048,
        "wins_vs_tfs": 10,
        "wins_vs_mkl": 17
      },
      {
        "method": "bfull_accurate",
        "graphs": 17,
        "median_gmean_vs_tfs": 1.2194150264866357,
        "median_gmean_vs_mkl": 2.311449622687617,
        "min_gmean_vs_tfs": 1.2157535252217064,
        "wins_vs_tfs": 10,
        "wins_vs_mkl": 17
      }
    ],
    "oracle_best_fast_gmean_vs_tfs": 1.3238165012335805,
    "oracle_best_fast_wins": 11,
    "oracle_is_not_implemented_adaptive_method": true,
    "anchor_min_ratio_range": [
      0.9733333333333333,
      1.0354236951776146
    ]
  },
  "paper_eligible": true,
  "issues": "No gate relaxation or historical/cross-node denominator substitution; fixed-method losses and oracle selection retained",
  "next": "Interpret degree-dependent crossover before any further optimization",
  "date": "2026-10-04T05:08:14.235748+00:00"
}
```

## paper-cache-build-20261004-131154

```json
{
  "id": "paper-cache-build-20261004-131154",
  "kind": "paper_cache_control_build",
  "status": "PASS",
  "exit_status": 0,
  "evidence": "/home/huangjianqiang_group/hdacp1/data/wzh/GCN-extra/runs/paper-cache-build-20261004-131154",
  "paper_eligible": false,
  "issues": "Interleaved method execution changes small-graph cache warmth, especially FP32 MKL; supplemental source-equivalent warmup plus five consecutive repetitions. Frozen kernels and gates unchanged.",
  "next": "Shared smoke then all-17 paired cache control",
  "date": "2026-10-04T05:11:58.725583+00:00"
}
```

## paper-cache-submit-smoke-20261004-131545

```json
{
  "id": "paper-cache-submit-smoke-20261004-131545",
  "kind": "source_warm_cache_control_submission",
  "status": "SUBMITTED",
  "job_id": "10864904",
  "mode": "smoke",
  "evidence": "/home/huangjianqiang_group/hdacp1/data/wzh/GCN-extra/runs/paper-cache-submit-smoke-20261004-131545",
  "paper_eligible": false,
  "issues": "Same frozen kernels/gates/inputs/output precision; only measured execution order differs",
  "next": "Check consecutive vs interleaved sensitivity, retaining both",
  "date": "2026-10-04T05:15:46.910980+00:00"
}
```

## paper-cache-smoke-10864904

```json
{
  "id": "paper-cache-smoke-10864904",
  "kind": "source_warm_cache_control",
  "status": "PASS",
  "exit_status": 0,
  "job_id": "10864904",
  "node": "qhcn049",
  "build": "/home/huangjianqiang_group/hdacp1/data/wzh/GCN-extra/runs/paper-cache-build-20261004-131154",
  "evidence": "/home/huangjianqiang_group/hdacp1/data/wzh/GCN-extra/runs/paper-cache-smoke-10864904",
  "completion": {
    "passed": 2,
    "failed": 0,
    "checks": 72,
    "mode": "smoke"
  },
  "paper_eligible": false,
  "issues": "Same graph/tensors/thread binding/NUMA policy/output precision/timing; original source anchor and immediate warmup plus consecutive method repeats; frozen numerical gates",
  "next": "Reconcile cache control with retained interleaved measurements",
  "date": "2026-10-04T05:15:49.421960+00:00"
}
```

## paper-cache-submit-high-20261004-131618

```json
{
  "id": "paper-cache-submit-high-20261004-131618",
  "kind": "source_warm_cache_control_submission",
  "status": "SUBMITTED",
  "job_id": "10864906",
  "mode": "high",
  "evidence": "/home/huangjianqiang_group/hdacp1/data/wzh/GCN-extra/runs/paper-cache-submit-high-20261004-131618",
  "paper_eligible": false,
  "issues": "Same frozen kernels/gates/inputs/output precision; only measured execution order differs",
  "next": "Check consecutive vs interleaved sensitivity, retaining both",
  "date": "2026-10-04T05:16:19.648158+00:00"
}
```

## paper-cache-submit-medium-20261004-131623

```json
{
  "id": "paper-cache-submit-medium-20261004-131623",
  "kind": "source_warm_cache_control_submission",
  "status": "SUBMITTED",
  "job_id": "10864907",
  "mode": "medium",
  "evidence": "/home/huangjianqiang_group/hdacp1/data/wzh/GCN-extra/runs/paper-cache-submit-medium-20261004-131623",
  "paper_eligible": false,
  "issues": "Same frozen kernels/gates/inputs/output precision; only measured execution order differs",
  "next": "Check consecutive vs interleaved sensitivity, retaining both",
  "date": "2026-10-04T05:16:24.631864+00:00"
}
```

## paper-cache-submit-low-20261004-131628

```json
{
  "id": "paper-cache-submit-low-20261004-131628",
  "kind": "source_warm_cache_control_submission",
  "status": "SUBMITTED",
  "job_id": "10864908",
  "mode": "low",
  "evidence": "/home/huangjianqiang_group/hdacp1/data/wzh/GCN-extra/runs/paper-cache-submit-low-20261004-131628",
  "paper_eligible": false,
  "issues": "Same frozen kernels/gates/inputs/output precision; only measured execution order differs",
  "next": "Check consecutive vs interleaved sensitivity, retaining both",
  "date": "2026-10-04T05:16:29.817880+00:00"
}
```

## paper-cache-scheduling-adjustment-20261004-133536

```json
{
  "id": "paper-cache-scheduling-adjustment-20261004-133536",
  "kind": "cache_control_scheduler_limit_only",
  "status": "PASS",
  "job_ids": [
    "10864906",
    "10864907",
    "10864908"
  ],
  "evidence": "/home/huangjianqiang_group/hdacp1/data/wzh/GCN-extra/runs/paper-cache-scheduling-adjustment-20261004-133536",
  "paper_eligible": false,
  "issues": "Original two-hour timeout overstates scheduling duration. Complete larger main sweep took at most 16m43s. Supplemental scope is smaller. Only scheduler timeout changes to 30 minutes; frozen kernels/gates/data/threads/affinity/memory/partition/exclusivity/timing boundaries unchanged.",
  "next": "Retain timeout outcomes if any; reconcile all cache-control outputs",
  "date": "2026-10-04T05:35:38.111582+00:00"
}
```

## paper-cache-high-10864906

```json
{
  "id": "paper-cache-high-10864906",
  "kind": "source_warm_cache_control",
  "status": "PASS",
  "exit_status": 0,
  "job_id": "10864906",
  "node": "qhcn819",
  "build": "/home/huangjianqiang_group/hdacp1/data/wzh/GCN-extra/runs/paper-cache-build-20261004-131154",
  "evidence": "/home/huangjianqiang_group/hdacp1/data/wzh/GCN-extra/runs/paper-cache-high-10864906",
  "completion": {
    "passed": 5,
    "failed": 0,
    "checks": 180,
    "mode": "high"
  },
  "paper_eligible": true,
  "issues": "Same graph/tensors/thread binding/NUMA policy/output precision/timing; original source anchor and immediate warmup plus consecutive method repeats; frozen numerical gates",
  "next": "Reconcile cache control with retained interleaved measurements",
  "date": "2026-10-04T05:48:12.490661+00:00"
}
```

## paper-cache-medium-10864907

```json
{
  "id": "paper-cache-medium-10864907",
  "kind": "source_warm_cache_control",
  "status": "PASS",
  "exit_status": 0,
  "job_id": "10864907",
  "node": "qhcn819",
  "build": "/home/huangjianqiang_group/hdacp1/data/wzh/GCN-extra/runs/paper-cache-build-20261004-131154",
  "evidence": "/home/huangjianqiang_group/hdacp1/data/wzh/GCN-extra/runs/paper-cache-medium-10864907",
  "completion": {
    "passed": 5,
    "failed": 0,
    "checks": 180,
    "mode": "medium"
  },
  "paper_eligible": true,
  "issues": "Same graph/tensors/thread binding/NUMA policy/output precision/timing; original source anchor and immediate warmup plus consecutive method repeats; frozen numerical gates",
  "next": "Reconcile cache control with retained interleaved measurements",
  "date": "2026-10-04T05:51:08.563447+00:00"
}
```

## paper-cache-low-10864908

```json
{
  "id": "paper-cache-low-10864908",
  "kind": "source_warm_cache_control",
  "status": "PASS",
  "exit_status": 0,
  "job_id": "10864908",
  "node": "qhcn819",
  "build": "/home/huangjianqiang_group/hdacp1/data/wzh/GCN-extra/runs/paper-cache-build-20261004-131154",
  "evidence": "/home/huangjianqiang_group/hdacp1/data/wzh/GCN-extra/runs/paper-cache-low-10864908",
  "completion": {
    "passed": 7,
    "failed": 0,
    "checks": 252,
    "mode": "low"
  },
  "paper_eligible": true,
  "issues": "Same graph/tensors/thread binding/NUMA policy/output precision/timing; original source anchor and immediate warmup plus consecutive method repeats; frozen numerical gates",
  "next": "Reconcile cache control with retained interleaved measurements",
  "date": "2026-10-04T05:55:18.550789+00:00"
}
```

## paper-cache-reconciliation-20261004

```json
{
  "id": "paper-cache-reconciliation-20261004",
  "kind": "execution_order_control_reconciliation",
  "status": "PASS",
  "report": "/home/huangjianqiang_group/hdacp1/data/wzh/GCN-extra/docs/PAPER_CACHE_CONTROL_RESULTS_20261004.md",
  "evidence": "/home/huangjianqiang_group/hdacp1/data/wzh/GCN-extra/runs/paper-cache-reconciled-20261004",
  "summary": {
    "graphs": 17,
    "numerical_checks": 612,
    "numerical_failures": 0,
    "measured_repetitions": 850,
    "source_input_hashes_match_main": true,
    "same_binary_hashes": true,
    "fixed": [
      {
        "method": "b8_fast",
        "graphs": 17,
        "consecutive_gmean_vs_tfs": 1.105749263059566,
        "consecutive_gmean_vs_mkl": 2.0573426850763235,
        "interleaved_gmean_vs_tfs": 1.1103264515904865,
        "interleaved_gmean_vs_mkl": 2.104667895542813,
        "wins_vs_tfs": 9,
        "wins_vs_mkl": 16
      },
      {
        "method": "b8_accurate",
        "graphs": 17,
        "consecutive_gmean_vs_tfs": 1.005135913059786,
        "consecutive_gmean_vs_mkl": 1.8701427957720151,
        "interleaved_gmean_vs_tfs": 1.0136172733180502,
        "interleaved_gmean_vs_mkl": 1.921351806456795,
        "wins_vs_tfs": 6,
        "wins_vs_mkl": 16
      },
      {
        "method": "b16_fast",
        "graphs": 17,
        "consecutive_gmean_vs_tfs": 1.2156395617942832,
        "consecutive_gmean_vs_mkl": 2.2618031444368496,
        "interleaved_gmean_vs_tfs": 1.2226753543235622,
        "interleaved_gmean_vs_mkl": 2.317629703615613,
        "wins_vs_tfs": 10,
        "wins_vs_mkl": 16
      },
      {
        "method": "b16_accurate",
        "graphs": 17,
        "consecutive_gmean_vs_tfs": 1.1445930939871658,
        "consecutive_gmean_vs_mkl": 2.1296150112618433,
        "interleaved_gmean_vs_tfs": 1.1481607022295304,
        "interleaved_gmean_vs_mkl": 2.176384220555021,
        "wins_vs_tfs": 9,
        "wins_vs_mkl": 16
      },
      {
        "method": "b64_fast",
        "graphs": 17,
        "consecutive_gmean_vs_tfs": 1.308859185605137,
        "consecutive_gmean_vs_mkl": 2.435246363039741,
        "interleaved_gmean_vs_tfs": 1.3011897199830935,
        "interleaved_gmean_vs_mkl": 2.4664568026240326,
        "wins_vs_tfs": 11,
        "wins_vs_mkl": 17
      },
      {
        "method": "b64_accurate",
        "graphs": 17,
        "consecutive_gmean_vs_tfs": 1.2617924426767824,
        "consecutive_gmean_vs_mkl": 2.3476745938250043,
        "interleaved_gmean_vs_tfs": 1.261220829948195,
        "interleaved_gmean_vs_mkl": 2.3906941838406714,
        "wins_vs_tfs": 11,
        "wins_vs_mkl": 17
      },
      {
        "method": "bfull_fast",
        "graphs": 17,
        "consecutive_gmean_vs_tfs": 1.2581041315920165,
        "consecutive_gmean_vs_mkl": 2.3408121702322155,
        "interleaved_gmean_vs_tfs": 1.2513960779370457,
        "interleaved_gmean_vs_mkl": 2.3720709761255754,
        "wins_vs_tfs": 11,
        "wins_vs_mkl": 17
      },
      {
        "method": "bfull_accurate",
        "graphs": 17,
        "consecutive_gmean_vs_tfs": 1.2212485249671163,
        "consecutive_gmean_vs_mkl": 2.2722391083031614,
        "interleaved_gmean_vs_tfs": 1.2194150264866357,
        "interleaved_gmean_vs_mkl": 2.311449622687617,
        "wins_vs_tfs": 10,
        "wins_vs_mkl": 17
      }
    ],
    "primary_statistic": "median of five consecutive repetitions after immediate warmup; same-process TFS/MKL denominator",
    "nodes": {
      "paper-cache-high-10864906": "qhcn819",
      "paper-cache-medium-10864907": "qhcn819",
      "paper-cache-low-10864908": "qhcn819"
    }
  },
  "paper_eligible": true,
  "issues": "Both protocols retained; same-process denominator, frozen kernel/gates and input hashes; cache effects not isolated from cross-run variability",
  "next": "Archive and publish all main and supplemental evidence",
  "date": "2026-10-04T05:56:20.386382+00:00"
}
```

## paper-method-package-20261004

```json
{
  "id": "paper-method-package-20261004",
  "kind": "controlled_method_archive",
  "status": "RECONCILED_READY_FOR_ARCHIVE",
  "evidence": "/home/huangjianqiang_group/hdacp1/data/wzh/GCN-extra/runs/paper-method-reconciled-20261004",
  "archive": "/home/huangjianqiang_group/hdacp1/data/wzh/GCN-extra/evidence-paper-methods-controlled-20261004.tar.gz",
  "paper_eligible": true,
  "issues": "All numerical gates and slow cases retained; no cross-node or historical denominator",
  "next": "Verify local mirrors and publish existing isolated experiment branch",
  "date": "2026-10-04T05:56:55.729881+00:00"
}
```

## paper-method-report-qa-20261004

```json
{
  "id": "paper-method-report-qa-20261004",
  "kind": "post_archive_report_visual_qa",
  "status": "PASS",
  "evidence": "/home/huangjianqiang_group/hdacp1/data/wzh/GCN-extra/runs/paper-method-report-qa-20261004",
  "paper_eligible": false,
  "changed_report_assets": {
    "scripts/plot_paper_methods.py": "fc8154362c53a846a7f8a888d9aa64d13b4012ad1c03f21f2a58b7548406cee7",
    "docs/figures/paper_methods_20261004/execution_order_control.png": "4e8887b185c847e4d3e0c1d5c30d3448fa06c2f25940097db5bea0f41f40d21f",
    "docs/figures/paper_methods_20261004/execution_order_control.pdf": "41e5a05894d827d78fc345448a4a1ed9b8f0609038d575eb159d5bae128a2308"
  },
  "benchmark_and_numerical_evidence_unchanged": true,
  "mirror_verified_files": 1176,
  "issues": "Initial local mirror hash check caught a concurrent plot layout edit; re-extraction succeeded and both mirrors verified all 1176 manifest files. Only then the legend was moved outside bars to expose final row numbers; PNG visually reviewed. A stalled upload connection left only the renderer updated, which the reporting-only hash gate rejected before recording success. Retry with BatchMode and ConnectTimeout=15 transferred both assets. Immutable archive retains its original reporting snapshot.",
  "next": "Publish verified benchmark evidence plus clearly recorded reporting-only revision",
  "date": "2026-10-04T06:04:15.944564+00:00"
}
```

## paper-method-publication-20261004

```json
{
  "id": "paper-method-publication-20261004",
  "kind": "controlled_methods_github_publication",
  "status": "PUBLISHED_VERIFIED",
  "source_evidence_commit": "0b20cc0ae1cc4749c7a24a256dae02dc8f78b54f",
  "branch": "gcn-extra-experiments-20261003",
  "repository": "https://github.com/huamiao123/GAT-TFS",
  "archive_sha256": "af7b17e5403f7f22e7baef1c4fc306525b68c7214f55565cee9e392d195556f4",
  "paper_eligible": true,
  "evidence": "/home/huangjianqiang_group/hdacp1/data/wzh/GCN-extra/runs/paper-method-publication-20261004",
  "issues": "17 graphs, original paper v3/source MKL, both measurement orders, fixed gates and negative results published; archive captures pre-publication handoff snapshot and publication is a subsequent history event",
  "next": "Controlled remeasurement complete; future mechanism/PMU/shape/checkpoint experiments remain separate scope",
  "date": "2026-10-04T06:07:27.811518+00:00"
}
```

## cleanup-current-20261004

```json
{
  "id": "cleanup-current-20261004",
  "date": "2026-10-04T06:44:20.920473+00:00",
  "kind": "user_authorized_historical_cleanup",
  "status": "CLEANED",
  "scope": "GCN-extra only; server wzh and local mirrors; experiment Git branch latest tree",
  "kept": "Original TFS, exact source MKL and validated modified TFS; both current measurement orders, 17 graphs including negative cases",
  "evidence": "/home/huangjianqiang_group/hdacp1/data/wzh/GCN-extra/runs/cleanup-current-20261004",
  "issues": "Previous bundles and numerical claims removed from active files. Existing Git commits remain; no history rewrite. Current frozen source snapshots stay byte-for-byte intact.",
  "next": "Use current cleaned archive and CURRENT_EVIDENCE_20261004.md"
}
```
