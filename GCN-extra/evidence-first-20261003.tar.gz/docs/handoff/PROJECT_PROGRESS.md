# PROJECT_PROGRESS — GCN-extra inference

Claims remain UNVERIFIED until qualified evidence is available.

## setup-20261003-gcn-extra

```json
{
  "id": "setup-20261003-gcn-extra",
  "kind": "setup",
  "status": "PASS",
  "purpose": "User-authorized new inference-only TFS extension experiment",
  "root": "/home/huangjianqiang_group/hdacp1/data/wzh/GCN-extra",
  "original_source_sha256": "4e574786055816df80beb6e68181fe19a8ee02cf4be1d43717bc1e79b88cab29",
  "agents_sha256": "55ac34d581d9cfda4e408ef5ad1fdb58c1dbf0cdd0c5fafbf725f5e31ff12ec7",
  "skill_sha256": "641694f2090f9b1581b32b64b8273ff6acc7fb470d0910ca9390f48766a4bcca",
  "scope_decision": "Inference plan and GCN-extra location explicitly override TFS-Train architecture scope. Workspace and evidence workflow still apply. Handoffs belong to GCN-extra; frozen TFS-Train/GAT evidence is untouched.",
  "experiments": "No compute job at setup; plan first shared-intel smoke then one exclusive-intel_expr 32-core paired run",
  "paper_eligible": false,
  "issues": "Original kernel ignores CSR values; graph audit is mandatory. Original gather is repeated per output panel; shared/replay controls expose this difference. Original BF16 is truncation.",
  "next": "Build; check numerical correctness before timings",
  "date": "2026-10-03T11:41:28.699876+00:00"
}
```

## build-20261003-194132

```json
{
  "id": "build-20261003-194132",
  "kind": "build",
  "status": "PASS",
  "exit_status": 0,
  "evidence": "/home/huangjianqiang_group/hdacp1/data/wzh/GCN-extra/runs/build-20261003-194132",
  "purpose": "Build unchanged Original TFS and block/local inference extension",
  "source_hashes": "source.sha256",
  "binary_hashes": "binary.sha256",
  "compiler": "compiler.txt",
  "timing_boundary": "not a benchmark",
  "paper_eligible": false,
  "issues": "See build.log; no new major issue if exit=0",
  "next": "shared intel correctness gate",
  "date": "2026-10-03T11:41:39.712809+00:00"
}
```

## submit-smoke-20261003-194254

```json
{
  "id": "submit-smoke-20261003-194254",
  "kind": "submission",
  "status": "SUBMITTED",
  "job_id": "10861412",
  "mode": "smoke",
  "nodes": 1,
  "evidence": "/home/huangjianqiang_group/hdacp1/data/wzh/GCN-extra/runs/submit-smoke-20261003-194254",
  "paper_eligible": false,
  "issues": "no new major issue",
  "next": "Collect job status and correctness before reporting speedup",
  "date": "2026-10-03T11:42:55.639016+00:00"
}
```

## smoke-10861412

```json
{
  "id": "smoke-10861412",
  "kind": "smoke",
  "status": "PASS",
  "exit_status": 0,
  "job_id": "10861412",
  "partition": "intel",
  "node": "qhcn006",
  "threads": "8",
  "evidence": "/home/huangjianqiang_group/hdacp1/data/wzh/GCN-extra/runs/smoke-10861412",
  "timing_boundary": "kernel includes original C-zero/AMX setup/output; prepared E2E includes 2 kernels+ReLU+intermediate BF16 conversion",
  "warmups": 1,
  "repeats": 2,
  "source_binary_hashes": "artifact.sha256 and build_source.sha256",
  "input_hashes": "dataset.sha256 plus per-graph info.json",
  "correctness": "per-graph correctness.csv; gate before timing",
  "results": "SUMMARY.md and per-graph timings/work/profiles CSV",
  "paper_eligible": false,
  "issues": "See stderr/status; sampled phase timings are advisory and sum thread time, not wall",
  "next": "Inspect accuracy and speedup; full 25 graphs and shape sensitivity remain pending",
  "date": "2026-10-03T11:43:01.248027+00:00"
}
```

## decision-20261003-numa-and-tail-gates

```json
{
  "id": "decision-20261003-numa-and-tail-gates",
  "kind": "implementation_decision",
  "status": "PASS",
  "evidence": "runs/smoke-10861412/lscpu.txt, numa_hardware.txt, smoke/correctness.csv",
  "findings": "37-node mixed-degree fixture passed. B=1 shared_fast is bitwise identical to unchanged Original TFS. Instrumented original matches unchanged original. Node qhcn006 is Xeon Max 9462, 2 sockets x 32 cores, 8 CPU NUMA domains.",
  "decision": "Use process-local interleaving across allocated socket NUMA domains for all methods. Add 137-node q130 fixture to exercise multiple B64 chunks and destination tails, plus all-empty 17-node fixture. These unresolved edge cases justify additional correctness testing before formal runs.",
  "scope": "Policy is per benchmark process; no shared configuration changes. All artifacts remain under GCN-extra.",
  "paper_eligible": false,
  "issues": "32 physical cores cannot occupy a single CPU NUMA domain on these SNC4 nodes; literal plan assumption adjusted with topology evidence.",
  "next": "Tail and empty correctness gates, then exclusive paired benchmark",
  "date": "2026-10-03T11:45:53.739974+00:00"
}
```

## submit-smoke-20261003-194557

```json
{
  "id": "submit-smoke-20261003-194557",
  "kind": "submission",
  "status": "SUBMITTED",
  "job_id": "10861414",
  "mode": "smoke",
  "nodes": 1,
  "evidence": "/home/huangjianqiang_group/hdacp1/data/wzh/GCN-extra/runs/submit-smoke-20261003-194557",
  "paper_eligible": false,
  "issues": "no new major issue",
  "next": "Collect job status and correctness before reporting speedup",
  "date": "2026-10-03T11:45:59.003901+00:00"
}
```

## smoke-10861414

```json
{
  "id": "smoke-10861414",
  "kind": "smoke",
  "status": "FAILED",
  "exit_status": 2,
  "job_id": "10861414",
  "partition": "intel",
  "node": "qhcn006",
  "threads": "8",
  "evidence": "/home/huangjianqiang_group/hdacp1/data/wzh/GCN-extra/runs/smoke-10861414",
  "timing_boundary": "kernel includes original C-zero/AMX setup/output; prepared E2E includes 2 kernels+ReLU+intermediate BF16 conversion",
  "warmups": 1,
  "repeats": 2,
  "source_binary_hashes": "artifact.sha256 and build_source.sha256",
  "input_hashes": "dataset.sha256 plus per-graph info.json",
  "correctness": "per-graph correctness.csv; gate before timing",
  "results": "SUMMARY.md and per-graph timings/work/profiles CSV",
  "paper_eligible": false,
  "issues": "See stderr/status; sampled phase timings are advisory and sum thread time, not wall",
  "next": "Inspect accuracy and speedup; full 25 graphs and shape sensitivity remain pending",
  "date": "2026-10-03T11:46:00.768047+00:00"
}
```

## issue-20261003-empty-mkl-csr

```json
{
  "id": "issue-20261003-empty-mkl-csr",
  "kind": "correctness_fix",
  "status": "FIX_IMPLEMENTED_PENDING_GATE",
  "affected_job": "10861414",
  "symptom": "17-node all-empty CSR rejected by mkl_sparse_s_create_csr; job failed before this fixture's timing. Mixed-degree 37-node and regular 137-node q130 fixtures passed.",
  "evidence": "runs/smoke-10861414/tail-n17-q0/stderr.log; tail-n137-q130/info.json; smoke/info.json",
  "root_cause": "oneMKL create interface rejects zero nnz/empty indices; mathematical operator remains well defined",
  "fix": "MKL adapter bypasses sparse handle for zero edges, zeros Z explicitly and retains ordinary SGEMM. Nonempty CSR path is unchanged.",
  "prevention": "Permanent all-empty fixture before formal acceptance; numerical gate still compares full outputs and FP64 samples",
  "source": "src/bench.cpp MKLGraph constructor/run",
  "paper_eligible": false,
  "next": "Rebuild and rerun meaningful smoke fixtures, then paired real-graph run",
  "date": "2026-10-03T11:47:24.929503+00:00"
}
```

## build-20261003-194728

```json
{
  "id": "build-20261003-194728",
  "kind": "build",
  "status": "PASS",
  "exit_status": 0,
  "evidence": "/home/huangjianqiang_group/hdacp1/data/wzh/GCN-extra/runs/build-20261003-194728",
  "purpose": "Build unchanged Original TFS and block/local inference extension",
  "source_hashes": "source.sha256",
  "binary_hashes": "binary.sha256",
  "compiler": "compiler.txt",
  "timing_boundary": "not a benchmark",
  "paper_eligible": false,
  "issues": "See build.log; no new major issue if exit=0",
  "next": "shared intel correctness gate",
  "date": "2026-10-03T11:47:35.682456+00:00"
}
```

## submit-smoke-20261003-194810

```json
{
  "id": "submit-smoke-20261003-194810",
  "kind": "submission",
  "status": "SUBMITTED",
  "job_id": "10861420",
  "mode": "smoke",
  "nodes": 1,
  "evidence": "/home/huangjianqiang_group/hdacp1/data/wzh/GCN-extra/runs/submit-smoke-20261003-194810",
  "paper_eligible": false,
  "issues": "no new major issue",
  "next": "Collect job status and correctness before reporting speedup",
  "date": "2026-10-03T11:48:11.815793+00:00"
}
```

## smoke-10861420

```json
{
  "id": "smoke-10861420",
  "kind": "smoke",
  "status": "PASS",
  "exit_status": 0,
  "job_id": "10861420",
  "partition": "intel",
  "node": "qhcn006",
  "threads": "8",
  "evidence": "/home/huangjianqiang_group/hdacp1/data/wzh/GCN-extra/runs/smoke-10861420",
  "timing_boundary": "kernel includes original C-zero/AMX setup/output; prepared E2E includes 2 kernels+ReLU+intermediate BF16 conversion",
  "warmups": 1,
  "repeats": 2,
  "source_binary_hashes": "artifact.sha256 and build_source.sha256",
  "input_hashes": "dataset.sha256 plus per-graph info.json",
  "correctness": "per-graph correctness.csv; gate before timing",
  "results": "SUMMARY.md and per-graph timings/work/profiles CSV",
  "paper_eligible": false,
  "issues": "See stderr/status; sampled phase timings are advisory and sum thread time, not wall",
  "next": "Inspect accuracy and speedup; full 25 graphs and shape sensitivity remain pending",
  "date": "2026-10-03T11:48:14.342993+00:00"
}
```

## submit-formal-20261003-194849

```json
{
  "id": "submit-formal-20261003-194849",
  "kind": "submission",
  "status": "SUBMITTED",
  "job_id": "10861421",
  "mode": "formal",
  "nodes": 1,
  "evidence": "/home/huangjianqiang_group/hdacp1/data/wzh/GCN-extra/runs/submit-formal-20261003-194849",
  "paper_eligible": false,
  "issues": "no new major issue",
  "next": "Collect job status and correctness before reporting speedup",
  "date": "2026-10-03T11:48:50.647779+00:00"
}
```

## formal-10861421

```json
{
  "id": "formal-10861421",
  "kind": "formal",
  "status": "PASS",
  "exit_status": 0,
  "job_id": "10861421",
  "partition": "intel_expr",
  "node": "qhcn818",
  "threads": "32",
  "evidence": "/home/huangjianqiang_group/hdacp1/data/wzh/GCN-extra/runs/formal-10861421",
  "timing_boundary": "kernel includes original C-zero/AMX setup/output; prepared E2E includes 2 kernels+ReLU+intermediate BF16 conversion",
  "warmups": 1,
  "repeats": 5,
  "source_binary_hashes": "artifact.sha256 and build_source.sha256",
  "input_hashes": "dataset.sha256 plus per-graph info.json",
  "correctness": "per-graph correctness.csv; gate before timing",
  "results": "SUMMARY.md and per-graph timings/work/profiles CSV",
  "paper_eligible": false,
  "issues": "See stderr/status; sampled phase timings are advisory and sum thread time, not wall",
  "next": "Inspect accuracy and speedup; full 25 graphs and shape sensitivity remain pending",
  "date": "2026-10-03T11:50:25.488195+00:00"
}
```

## decision-20261003-original-zeroing-controls

```json
{
  "id": "decision-20261003-original-zeroing-controls",
  "kind": "performance_diagnosis",
  "status": "CONTROL_IMPLEMENTED_PENDING_GATE",
  "affected_job": "10861421",
  "result": "Four graphs passed numerical gates and 5-repeat exclusive medians. Full local improves reddit E2E 292.841 to 150.660 ms; Pokec 221.242 to 210.465 ms. Original TFS underperforms MKL on reddit/Pokec, so paper baseline trend is not reproduced yet.",
  "root_cause_evidence": "soc-Pokec/profiles.csv: original serial output_zero=65.504 ms, original uninstrumented kernel median=110.746 ms; same zero in local kernel=65.763 ms, kernel median=101.821 ms",
  "source_proof": "Original loop writes all 128 columns of every destination row, including zero-degree rows; full C clear is redundant. New shared local kernel skips all-empty tiles, so owner-thread zeroing is needed there when global clear is removed.",
  "decision": "Keep unchanged original and all first-run evidence. Add exact original function minus only global memset; add matching nozero local variants. NaN-prefill control outputs before correctness, check bitwise original equality, rerun before comparing algorithm gains.",
  "precision": "Identical source-compatible BF16 inputs/weights and quantized MKL reference; Fast extra quantization remains explicit",
  "paper_eligible": false,
  "next": "Build/nozero correctness gate; paired exclusive run including both old and zero-free paths",
  "date": "2026-10-03T11:59:17.293435+00:00"
}
```

## build-20261003-195921

```json
{
  "id": "build-20261003-195921",
  "kind": "build",
  "status": "PASS",
  "exit_status": 0,
  "evidence": "/home/huangjianqiang_group/hdacp1/data/wzh/GCN-extra/runs/build-20261003-195921",
  "purpose": "Build unchanged Original TFS and block/local inference extension",
  "source_hashes": "source.sha256",
  "binary_hashes": "binary.sha256",
  "compiler": "compiler.txt",
  "timing_boundary": "not a benchmark",
  "paper_eligible": false,
  "issues": "See build.log; no new major issue if exit=0",
  "next": "shared intel correctness gate",
  "date": "2026-10-03T11:59:27.708706+00:00"
}
```

## submit-smoke-20261003-200016

```json
{
  "id": "submit-smoke-20261003-200016",
  "kind": "submission",
  "status": "SUBMITTED",
  "job_id": "10861922",
  "mode": "smoke",
  "nodes": 1,
  "evidence": "/home/huangjianqiang_group/hdacp1/data/wzh/GCN-extra/runs/submit-smoke-20261003-200016",
  "paper_eligible": false,
  "issues": "no new major issue",
  "next": "Collect job status and correctness before reporting speedup",
  "date": "2026-10-03T12:00:18.176860+00:00"
}
```

## smoke-10861922

```json
{
  "id": "smoke-10861922",
  "kind": "smoke",
  "status": "PASS",
  "exit_status": 0,
  "job_id": "10861922",
  "partition": "intel",
  "node": "qhcn016",
  "threads": "8",
  "evidence": "/home/huangjianqiang_group/hdacp1/data/wzh/GCN-extra/runs/smoke-10861922",
  "timing_boundary": "kernel includes original C-zero/AMX setup/output; prepared E2E includes 2 kernels+ReLU+intermediate BF16 conversion",
  "warmups": 1,
  "repeats": 2,
  "source_binary_hashes": "artifact.sha256 and build_source.sha256",
  "input_hashes": "dataset.sha256 plus per-graph info.json",
  "correctness": "per-graph correctness.csv; gate before timing",
  "results": "SUMMARY.md and per-graph timings/work/profiles CSV",
  "paper_eligible": false,
  "issues": "See stderr/status; sampled phase timings are advisory and sum thread time, not wall",
  "next": "Inspect accuracy and speedup; full 25 graphs and shape sensitivity remain pending",
  "date": "2026-10-03T12:00:22.409445+00:00"
}
```

## submit-formal-20261003-200150

```json
{
  "id": "submit-formal-20261003-200150",
  "kind": "submission",
  "status": "SUBMITTED",
  "job_id": "10861923",
  "mode": "formal",
  "nodes": 1,
  "evidence": "/home/huangjianqiang_group/hdacp1/data/wzh/GCN-extra/runs/submit-formal-20261003-200150",
  "paper_eligible": false,
  "issues": "no new major issue",
  "next": "Collect job status and correctness before reporting speedup",
  "date": "2026-10-03T12:01:52.619415+00:00"
}
```

## formal-10861923

```json
{
  "id": "formal-10861923",
  "kind": "formal",
  "status": "PASS",
  "exit_status": 0,
  "job_id": "10861923",
  "partition": "intel_expr",
  "node": "qhcn819",
  "threads": "32",
  "evidence": "/home/huangjianqiang_group/hdacp1/data/wzh/GCN-extra/runs/formal-10861923",
  "timing_boundary": "kernel includes original C-zero/AMX setup/output; prepared E2E includes 2 kernels+ReLU+intermediate BF16 conversion",
  "warmups": 1,
  "repeats": 5,
  "source_binary_hashes": "artifact.sha256 and build_source.sha256",
  "input_hashes": "dataset.sha256 plus per-graph info.json",
  "correctness": "per-graph correctness.csv; gate before timing",
  "results": "SUMMARY.md and per-graph timings/work/profiles CSV",
  "paper_eligible": false,
  "issues": "See stderr/status; sampled phase timings are advisory and sum thread time, not wall",
  "next": "Inspect accuracy and speedup; full 25 graphs and shape sensitivity remain pending",
  "date": "2026-10-03T12:03:05.322148+00:00"
}
```
