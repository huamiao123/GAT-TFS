# GCN-extra

Inference-only extension of ICPP Original TFS: DegreeSort + 16 destination rows +
neighbor-block FP32 reduction + immediate AMX GeMM. No full global AH in fused
paths. Original source is preserved byte for byte.

Remote root: `/home/huangjianqiang_group/hdacp1/data/wzh/GCN-extra`.
Read-only dataset root: `/home/huangjianqiang_group/hdacp1/data/yx/TFS/data`.

See IMPLEMENTATION_CONTRACT.md and docs/experiment_plan_v1.txt for the operator,
precision controls, numerical gates, timing boundaries and modeled work counts.
Build with `bash scripts/build.sh`; correctness uses scripts/smoke.slurm;
first exclusive 32-core experiment uses scripts/formal.slurm. Each build/job
has an immutable run directory with source snapshot, manifests, hashes, raw CSV,
stdout/stderr and all three synchronized project handoffs.

Kernel profiles are separate sampled runs, not speedup timings. FP32 MKL is
reported separately from the BF16-input/weight MKL reference. Experiments use
random H/W and sum adjacency; task accuracy remains unverified.

First completed evidence: `runs/formal-10861421` (full B sweep) and
`runs/formal-10861923` (stronger zero-free Original TFS and paired controls).
Report: `docs/FIRST_RESULTS_20261003.md`; standalone plots: `docs/figures/`.
The final algorithm comparison uses original_nozero versus matching local nozero
variants. Raw unchanged original remains in every comparison.

Complete nozero neighbor-block sweeps use `--block-controls --blocks
2,4,8,16,32,64,full`; this runs both Fast and Accurate, including two-layer E2E.
`--controls` retains the previous limited zeroing controls unchanged.
Submit the full sweep with `GCN_BLOCK_SWEEP=1 GCN_REPEATS=10 bash
scripts/submit.sh formal` after the shared correctness gate. The same environment
flag on `submit.sh smoke` tests all block sizes, empty rows and tail fixtures.
Actual configuration is saved in each run's `measurement_config.txt`.

Canonical 25-graph coverage uses `scripts/graph_inventory.py` (header-only
inspection), then `GCN_BLOCK_SWEEP=1 GCN_REPEATS=10
GCN_GRAPH_LIST=/absolute/path/to/inventory.json bash scripts/submit.sh suite`.
The suite uses one exclusive node, 32 physical cores, 448 GiB and a two-hour
limit. It records per-graph commands, full input SHA256, statuses and failures;
incompatible/nonunit data is retained and rejected, without changing files.
`graph_suite_report.py` gives all-graph and high-average-degree tables. It calls
the best measured B an oracle result, not an implemented adaptive selector.

The memory lifetime adjustment frees three kernel-validation reference arrays
before allocating two-layer references, outside all measured intervals. Large
graphs exceeding one socket's memory capacity interleave across online CPU NUMA
domains, equally for every method; this difference is recorded per graph.
