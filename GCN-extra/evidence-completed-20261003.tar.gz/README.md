# GCN-extra

Inference-only extension of ICPP Original TFS: DegreeSort + 16 destination rows +
neighbor-block FP32 reduction + immediate AMX GeMM. No full global AH in fused
paths. Original source is preserved byte for byte.

Remote root: `/home/huangjianqiang_group/hdacp1/data/wzh/GCN-extra`.
Read-only dataset root: `/home/huangjianqiang_group/hdacp1/data/yx/TFS/data`.

See IMPLEMENTATION_CONTRACT.md and docs/experiment_plan_v1.txt for the operator,
precision controls, numerical gates, timing boundaries and modeled work counts.
Build with `bash scripts/build.sh`; correctness uses scripts/smoke.slurm;
first exclusive 32-core experiment uses scripts/formal.slurm. Each build/job
has an immutable run directory with source snapshot, manifests, hashes, raw CSV,
stdout/stderr and all three synchronized project handoffs.

Kernel profiles are separate sampled runs, not speedup timings. FP32 MKL is
reported separately from the BF16-input/weight MKL reference. Experiments use
random H/W and sum adjacency; task accuracy remains unverified.

First completed evidence: `runs/formal-10861421` (full B sweep) and
`runs/formal-10861923` (stronger zero-free Original TFS and paired controls).
Report: `docs/FIRST_RESULTS_20261003.md`; standalone plots: `docs/figures/`.
The final algorithm comparison uses original_nozero versus matching local nozero
variants. Raw unchanged original remains in every comparison.
