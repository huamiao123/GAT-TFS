import pathlib, json, hashlib, shutil, zipfile

base=pathlib.Path(__file__).parent
def read_json(name):return json.loads((base/name).read_text(encoding='utf8'))
restored=read_json('coverage_history_restore.json')
assert restored['files']==3969 and not restored['missing'] and not restored['mismatches']
history=read_json('coverage_history_raw.json')['runs']
legacy=[v for k,v in history.items() if k.startswith(('formal-','smoke-'))]
assert sum(v['measured_rows'] for v in legacy)==10294
assert all(v['measured_rows']==v['stdout_matches'] and not v['summary_mismatches'] for v in legacy)
assert all(v['measured_rows']==v['all_timing_log_matches'] and not v['summary_mismatches'] for k,v in history.items() if k.startswith('source-'))
assert history['paper-formal-10864848']['raw_repeat_log_matches']==340
assert not history['paper-formal-10864848']['errors']
oct07=read_json('coverage_oct07.json')
assert oct07['csv_rows']==37110 and oct07['csv_unmatched']==0 and oct07['raw_unrepresented']==0
oct04=read_json('coverage_oct04_remote_raw_summary.json')
assert oct04['initial_sm']['raw_time_rows']==2720 and not oct04['initial_sm']['missing']
assert oct04['feature_final']['raw_time_rows']==3600 and oct04['feature_final']['missing_time_rows']==0
server=read_json('coverage_server.json')
assert len(server['units'])==36 and len(server['runs'])==140
bundle=base/'coverage-audit-20261018'
bundle.mkdir(exist_ok=True)
readable=[
 'EXPERIMENT_COVERAGE_AUDIT_20261018.md','CURRENT_HANDOFF_COVERAGE_PREFIX.md',
 'coverage_history.md','coverage_history.json','coverage_oct04.md','coverage_oct04.json',
 'coverage_oct07.md','coverage_oct07.json','coverage_server.md','coverage_server.json',
 'coverage_misc_versions.md','coverage_misc_versions.json',
 'coverage_late_versions.md','coverage_late_versions.json',
 'publish_coverage_server.py','coverage_history_raw.py',
 'coverage_history_raw.json','coverage_oct04_remote_raw_summary.json',
 'coverage_oct04_raw_verification.json','coverage_oct07_stats.json'
]
for name in readable:
    assert (base/name).is_file(),name
    shutil.copyfile(base/name,bundle/name)

# Full machine evidence is compressed; individual report/ledger files stay readable.
include=sorted(p for p in base.glob('coverage*') if p.is_file() and p.suffix in ('.json','.py','.txt') and p.name not in readable)
include += [base/'server_inventory_raw.json',base/'reconcile_coverage_reports.py',base/'assemble_coverage_bundle.py']
entry_hash={}
with zipfile.ZipFile(bundle/'coverage_machine_evidence.zip','w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    for p in include:
        assert p.exists()
        data=p.read_bytes();entry_hash[p.name]=hashlib.sha256(data).hexdigest();z.writestr(p.name,data)
    z.writestr('sha256.json',json.dumps(entry_hash,indent=2))
with zipfile.ZipFile(bundle/'coverage_machine_evidence.zip') as z:
    assert z.testzip() is None
    for name,h in entry_hash.items():assert hashlib.sha256(z.read(name)).hexdigest()==h

shutil.copyfile(base/'coverage_precleanup.tar.gz',bundle/'precleanup-8aeef16.tar.gz')
readme='''# Coverage audit evidence bundle

Read ../EXPERIMENT_COVERAGE_AUDIT_20261018.md first. Old review and experiment files are not modified.

- coverage_*.md: human-readable per-scope review, explicit errors, review depth and remaining limitations.
- coverage_*.json: per-experiment/run coverage and raw comparison results.
- coverage_machine_evidence.zip: full inventories, Git history/tree, source diffs, per-record extraction, and additional audit scripts. Internal sha256.json covers each entry.
- precleanup-8aeef16.tar.gz: GitHub archive of the pre-cleanup commit; original GCN-extra evidence was restored locally and all 3969 files checked against Git blob hashes. This archive is retained for recovery, not executed.
- coverage_history_raw.py: read-only parser with --root <restored-GCN-extra> --out <output-dir>. It reads existing logs and CSV; it does not run benchmarks. Other scripts in the ZIP retain the original local path constants and may need those constants adjusted before reuse.
- coverage_delivery_manifest.json: SHA256 of each delivered file. publish_coverage_server.py checks the manifest, preserves previous CURRENT_HANDOFF, appends the new event, then verifies all three persistent ledgers.

Inventory counts describe the pre-delivery server snapshot. This handoff itself adds files and an event, so a later filesystem count will differ. Timing rows are not experiment counts. Failure/partial/smoke results are not silently promoted to valid performance evidence.
'''
(bundle/'README.md').write_text(readme,encoding='utf8')
manifest={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(bundle.iterdir()) if p.is_file() and p.name!='coverage_delivery_manifest.json'}
(bundle/'coverage_delivery_manifest.json').write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf8')
print(json.dumps({'files':len(manifest),'bytes':sum(p.stat().st_size for p in bundle.iterdir() if p.is_file()),'report_sha256':manifest['EXPERIMENT_COVERAGE_AUDIT_20261018.md'],'zip_entries':len(entry_hash)}))
