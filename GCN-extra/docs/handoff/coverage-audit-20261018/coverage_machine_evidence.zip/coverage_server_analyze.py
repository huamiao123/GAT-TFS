import json,collections,re
from pathlib import Path
base=Path(__file__).parent; snapshot=base.parent/'tfs18'
d=json.loads((base/'server_inventory_raw.json').read_text(encoding='utf8'))
files={x['path']:x for x in d['files']}; local={str(p.relative_to(snapshot)).replace('\\','/'):p for p in snapshot.rglob('*') if p.is_file()}
def dirs(paths,prefix):return sorted({x[len(prefix):].split('/')[0] for x in paths if x.startswith(prefix) and '/' in x[len(prefix):]})
print('TOP_SERVER',collections.Counter(x.split('/')[0] for x in files))
print('TOP_GITHUB',collections.Counter(x.split('/')[0] for x in local))
for section in ['experiments','results','runs']:
 sd=dirs(files,section+'/');ld=dirs(local,section+'/')
 print('\nSECTION',section,'SERVER',len(sd),'GITHUB',len(ld))
 for x in sd:
  prefix=section+'/'+x+'/'
  n=sum(y.startswith(prefix) for y in files);m=sum(y.startswith(prefix) for y in local)
  relocated='results/crosslayer-fusion-20261008/'+prefix
  r=sum(y.startswith(relocated) for y in local)
  print(x,'server_files',n,'github_same',m,'github_archive',r)
ev=[]
for s in d['event_files']['docs/handoff/events.jsonl'].splitlines():
 try:ev.append(json.loads(s))
 except:pass
print('\nEVENTS',len(ev),'KEYS',collections.Counter(k for e in ev for k in e))
print('FIRST',json.dumps(ev[:3],ensure_ascii=False)[:6000])
print('LAST',json.dumps(ev[-3:],ensure_ascii=False)[:6000])
print('ONLY SERVER ROOTS')
for x in sorted(set(files)-set(local)):
 if x.count('/')<=1:print(x)
(base/'coverage_server_inventory.json').write_text(json.dumps({'server_file_count':len(files),'github_file_count':len(local),'server_files':d['files'],'server_directories':d['directories'],'events':ev,'github_paths':sorted(local)},indent=2,ensure_ascii=False),encoding='utf8')
