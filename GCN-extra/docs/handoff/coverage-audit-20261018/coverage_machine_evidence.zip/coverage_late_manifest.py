import json
from collections import Counter
from pathlib import Path

p = Path(__file__).parent
raw = json.loads((p / 'coverage_late_raw.json').read_text(encoding='utf-8'))
checks = json.loads((p / 'coverage_late_checks.json').read_text(encoding='utf-8'))
notes = {
 'frontier-certificate-20261008-01': ('link_failure', 'std::filesystem undefined references; compile stderr inspected'),
 'frontier-certificate-20261008-02': ('link_fix', 'Adds -lstdc++fs; certificate C++ byte-identical to 01; restricted certificate completes'),
 'frontier-structure-20261008-01': ('structural_run', 'Structural/oracle and deliberate malformed-input checks; not kernel timing'),
 'recompute-audit-20261008-01': ('staging_failure', 'Missing frozen frontier_prior_inputs.json; stage.py NAMES fixed next version'),
 'recompute-audit-20261008-02': ('python_failure', "Hash sentinel b causes UnboundLocalError; next version uses b''"),
 'recompute-audit-20261008-03': ('cancelled_incomplete', 'Python per-edge scan cancelled; no result JSON despite event exit_code 0'),
 'recompute-audit-20261008-04': ('prepared_only', 'Five files, no job or result'),
 'recompute-audit-20261008-05': ('scanner_rewrite', 'C++ two-pass/sort structural scan completes four graphs; not inference kernel'),
 'recompute-window-20261008-01': ('structural_run_superseded_counter', 'PASS with four graphs; old lifecycle counter superseded by 04'),
 'recompute-window-20261008-02': ('compile_failure_new_mode', 'Adds -1 mode but unsigned loop causes narrowing into int32 field'),
 'recompute-window-20261008-03': ('compile_fix_old_counter', 'Signed loop fixes build; four graphs, thirteen windows; old lifecycle counter'),
 'recompute-window-20261008-04': ('lifecycle_model_fix', 'Subsequent regeneration groups now begin lifetime at starts[g] instead of original producer'),
 'recompute-window-kernel-build-20261008-193715': ('compile_failure', 'using TR conflicts with TR macro'),
 'recompute-window-kernel-build-20261008-193923': ('compile_failure', 'Wrong include path to absent publish directory'),
 'recompute-window-kernel-build-20261008-194137': ('compile_fix', 'Restore original/src includes; no new dataflow relative to failed versions'),
 'recompute-window-kernel-10900289': ('kernel_run', 'Two WINDOW_RESULT rows and output gate'),
 'recompute-window-sweep-10900343': ('partial_sweep', 'Only W=1 retained; PASS is not nine-window coverage'),
 'recompute-window-sweep-10900360': ('expanded_sweep', 'Nine positive window values retained'),
 'recompute-window-parallel-build-20261008-202152': ('compile_failure', 'vector locals(size_t(threads)) vexing parse'),
 'recompute-window-parallel-build-20261008-202420': ('compile_fix', 'static_cast size plus WINDOW_KERNEL_NO_MAIN guard'),
 'recompute-window-parallel-build-20261008-211935': ('compile_failure_new_order', 'Adds identity/min_source ordering; fails missing std::iota'),
 'recompute-window-parallel-build-20261008-212208': ('compile_fix', 'Adds numeric header'),
 'recompute-window-parallel-10900662': ('timing_run', 'Degree only; three raw pairs, one result'),
 'recompute-window-parallel-10901373': ('timing_run', 'Three orders; three pairs each'),
 'recompute-window-parallel-cross-10901444': ('timing_run', 'Two graphs by three orders'),
 'recompute-window-parallel-exclusive-10901902': ('timing_run', 'Exclusive run; two graphs by three orders'),
 'recompute-window-batch-build-20261008-221327': ('new_packing_mechanism', 'Collect missing sources across multiple destination tiles, then pack AMX 16 rows'),
 'recompute-window-batch-20261008-221757': ('input_path_failure', 'Cannot open roadNet-CA CSR; srun exit 1; no PAR results'),
 'recompute-window-batch-20261008-222602': ('input_path_failure', 'Cannot open roadNet-CA CSR; srun exit 1; no PAR results'),
 'recompute-window-batch-20261008-222234': ('outer_status_disagrees_with_raw', '108 pairs/36 results/36 gates exact=1, event FAILED; acceptance script not recovered'),
 'recompute-window-batch-20261008-222837': ('outer_status_disagrees_with_raw', '108 pairs/36 results/36 gates exact=1, event FAILED; acceptance script not recovered'),
 'recompute-window-interleave-build-20261008-230314': ('measurement_schedule_change', 'Six alternating timing reps; RESULT upper median, gate second-smallest'),
 'recompute-window-interleave-20261008-230519': ('timing_run_statistic_issue', 'RoadNet batch16; three six-sample results'),
 'recompute-window-interleave-20261008-230957': ('timing_run_statistic_issue', 'Amazon batch16; three six-sample results'),
 'recompute-window-interleave-20261008-231443': ('timing_run_statistic_issue', 'RoadNet batch64; three six-sample results'),
 'recompute-window-interleave-20261008-233649': ('timing_run_statistic_issue', 'RoadNet batch16; three six-sample results; not proof failed adaptive build worked'),
 'recompute-window-interleave-build-20261008-233639': ('failure_log_missing', 'Actually adaptive_build; FAILED/1; only 12 files locally and on server, no compiler log'),
 'recompute-window-adaptive-build-20261008-233758': ('adaptive_prototype_v1', 'No warmup; fallback returns zero candidate time and copies baseline output'),
 'recompute-window-adaptive-20261008-233857': ('adaptive_run_invalid_fallback_timing', 'Road fused timed; Amazon/Reddit zero candidate time is not speedup'),
 'recompute-window-adaptive-build-20261008-234221': ('measurement_fix_partial', 'Adds warmup and fallback baseline rerun; assigns candidate time equal baseline time'),
 'recompute-window-adaptive-20261008-234255': ('adaptive_run_fallback_not_independent', 'Road fused timed; fallback 1.0 is assignment, not independent timing'),
 'source-partition-build-20261008-210228': ('structural_analyzer_build', 'Source-overlap analyzer; not kernel'),
 'source-partition-10901309': ('structural_run', 'Six PARTITION rows'),
 'source-partition-cross-10901392': ('structural_run', 'Twelve PARTITION rows'),
 'source-partition-cross-10902064': ('structural_run', 'Forty-two PARTITION rows'),
 'source-partition-cross-10902071': ('structural_run', 'Eighteen PARTITION rows'),
 'source-partition-weighted-build-20261008-232004': ('weighted_model_extension', 'Weight unique sources by CSR row degree; denominator global consumed-source row-degree sum, not E'),
 'source-partition-weighted-20261008-232054': ('structural_run', 'Eighteen PARTITION rows, six orders'),
 'source-partition-weighted-build-20261008-232709': ('new_order_with_initialization_issue', 'Adds hot_source, but hot_src starts as node 0 rather than first neighbor'),
 'source-partition-weighted-20261008-232839': ('structural_run', 'Twenty-one PARTITION rows, includes hot_source'),
 'source-partition-weighted-heldout-20261008-234650': ('structural_run', 'Thirty PARTITION rows; weighted six-order binary, not hot_source'),
 'source-partition-weighted-roadusa-20261008-235043': ('structural_run', 'Six PARTITION rows; weighted binary, no runtime validation'),
}
assert set(notes) == {r['run'] for r in raw}
entries = []
for r in raw:
    category, finding = notes[r['run']]
    times = [t for t in checks['timing_groups'] if t['run'] == r['run']]
    entries.append({
        'run': r['run'], 'category': category, 'finding': finding,
        'file_count': len(r['files']), 'record_tag_counts': dict(Counter(z['tag'] for z in r['records'])),
        'timing_groups': len(times), 'paired_raw_rows': sum(t['samples'] for t in times),
        'review_depth': ['file_and_event_inventory', 'available_error_and_result_logs', 'frozen_source_diff_where_available', 'stored_raw_arithmetic_where_applicable'],
        'source_files': r['sources'],
        'event_evidence': [{'path': e['path'], 'status': e['value'].get('status'), 'kind': e['value'].get('kind'), 'job': e['value'].get('job', e['value'].get('job_id'))} for e in r['events']],
        'log_evidence': [{'path': l['path'], 'line_count': l['lines'], 'errors': l['errors']} for l in r['logs']],
        'limitations': ['No benchmark rerun or complete assembly audit'] + (['Compiler log missing both snapshot and server'] if category == 'failure_log_missing' else [])
    })
report = {
 'scope': '2026-10-08 late frontier/recompute/source-partition historical versions only',
 'snapshot_sha': '9369b9e0491d59e328a99153b6d97314c62285da',
 'snapshot_prefix': 'results/crosslayer-fusion-20261008/runs',
 'review_date': '2026-10-18',
 'summary': {
  'containers': len(entries), 'timing_groups': len(checks['timing_groups']),
  'paired_raw_rows': sum(t['samples'] for t in checks['timing_groups']),
  'six_sample_upper_median_groups': sum(t['samples'] == 6 for t in checks['timing_groups']),
  'event_result_gate_rows_checked': sum(t['rows'] for t in checks['event_raw_checks']),
  'event_result_gate_rows_absent_from_raw': sum(t['not_in_raw'] for t in checks['event_raw_checks']),
  'partition_rows_checked': len(checks['partition_checks']),
  'partition_edge_and_unique_duplication_all_pass': all(t['edge_check'] and t['duplication_ok'] for t in checks['partition_checks']),
  'window_ratio_rows_checked': sum(t['ratio_checks'] for t in checks['structural_json_checks']),
  'window_ratio_all_pass': all(t['ratios_pass'] for t in checks['structural_json_checks']),
 },
 'review_boundaries': [
  '52 containers is the exact selected prefix set, not all GCN-extra experiments.',
  '233639 adaptive build has no compiler log: 12-file inventory confirmed locally and on server.',
  '372 raw timing pairs include assigned/zero adaptive fallback times and are not all independent measurements.',
  'Weighted denominator global_weight absent from logs; cannot independently validate weighted ratio without CSR.',
  'Window lifecycle fixed at 04, but row/column-degree and row/group-unit model concerns remain.',
  'Batch FAILED status contradicts completed raw gates; exact outer acceptance threshold not recovered.',
  'No kernel execution, performance rerun, full CSR replay or complete assembly audit.',
 ],
 'artifacts': ['coverage_late_versions.md', 'coverage_late_raw.json', 'coverage_late_checks.json', 'coverage_late_diffs.txt', 'coverage_late_diff_manifest.json'],
 'lineage': entries,
}
(p/'coverage_late_versions.json').write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding='utf-8')
print(json.dumps(report['summary'], indent=2))
