from pathlib import Path
import json,collections
base=Path(__file__).parent
old=json.loads((base/'coverage_tree_precleanup.json').read_text(encoding='utf8'))
new=json.loads((base/'github_tree.json').read_text(encoding='utf8'))
assert not old.get('truncated') and not new.get('truncated')
def files(tree):return {x['path'][10:]:x for x in tree['tree'] if x['type']=='blob' and x['path'].startswith('GCN-extra/')}
a,b=files(old),files(new)
gone={k:v for k,v in a.items() if k not in b}
counts=collections.Counter(k.split('/')[0] for k in gone)
dirs=collections.Counter('/'.join(k.split('/')[:2]) if '/' in k else k for k in gone)
out={'precleanup_files':len(a),'current_files':len(b),'missing_from_head':len(gone),'missing_bytes':sum(x['size'] for x in gone.values()),'missing_top':dict(counts),'missing_by_run_or_group':dict(sorted(dirs.items())),'missing_paths':list(gone)}
(base/'coverage_history_inventory.json').write_text(json.dumps(out,indent=2),encoding='utf8')
print(json.dumps({k:v for k,v in out.items() if k!='missing_paths'},indent=2))
