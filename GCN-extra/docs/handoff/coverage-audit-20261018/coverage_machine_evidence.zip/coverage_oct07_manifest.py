from pathlib import Path
import json
P=Path('C:/Users/花喵/tmp/tfs_deep_review_20261018')
R=Path('C:/Users/花喵/tmp/tfs18/results/crosslayer-fusion-20261008')
d=json.loads((P/'coverage_oct07_raw.json').read_text(encoding='utf8'))
stats=json.loads((P/'coverage_oct07_stats.json').read_text(encoding='utf8'))
residual={
'grouping-balance':['full real CSR independent minhash/LRU replay','hardware cache causality','GROUP_STRUCTURE duplicate windows weight short rows'],
'order-balance':['all PMU per-thread accounting rederived independently','application accuracy','Pused map/layout confound remains intentional'],
'state-reuse':['all unprofiled hot loops instruction-by-instruction spill audit','arbitrary-input numerical guarantee'],
'pair-plan':['full real CSR pairing metadata rebuilt independently','all codegen/control instruction attribution'],
'pair-order-control':['real-graph generalization not in this round','hardware cause of order effect'],
'order-share-factorial':['all seed significance assessment','17-graph expansion not performed because preregistered gate failed'],
'access-prefetch':['cache/MLP causal attribution','all normalized disassembly identities independently reimplemented','distance optimum outside scope'],
'event-trace':['all real CSR events independently replayed locally','all codegen comparison independently reconstructed','production full-row executor not implemented']}
out={'snapshot':'9369b9e0491d59e328a99153b6d97314c62285da','scope':'8 families under results/crosslayer-fusion-20261008; read-only audit, no benchmark rerun','review_depth_definition':'runtime and variant code traced; failed builds/smokes retained; every saved graph-local primary timing parsed and CSV crosschecked; selected structural/PMU/assembly controls reviewed, not universal formal verification','csv_files':len(stats['csv_checks']),'csv_rows':sum(x['csv_rows'] for x in stats['csv_checks']),'csv_unmatched':sum(x['unmatched'] for x in stats['csv_checks']),'raw_unrepresented':sum(x['unrepresented_raw'] for x in stats['csv_checks']),'families':[]}
for fam,runs in d.items():
 f={'family':fam,**stats['families'][fam],'review_depth':'runtime+variant_lineage+all_primary_raw+gate_failure_inventory','remaining_unverified':residual[fam],'lineage':[]}
 for run in runs:
  root=R/'runs'/run['run']; launches={}
  for p in (root/'launcher').glob('*/job_id.txt'):
   jid=p.read_text(encoding='utf8').strip().split(';')[0];cf=p.parent/'command.json'
   cmd=json.loads(cf.read_text(encoding='utf8')) if cf.exists() else []
   launches[jid]={'exclusive':'--exclusive' in cmd,'launch_command':str(cf.relative_to(R))}
  rr={'run':run['run'],'state':'has_logs' if run['jobs'] else 'build_only','jobs':[],'submitted_without_logs':[]}
  for j in run['jobs']:
   env=j.get('environment.json',{});jid=j['job'].rsplit('-',1)[-1]
   jj={'job':j['job'],'partition':env.get('SLURM_JOB_PARTITION'),'threads':env.get('OMP_NUM_THREADS'),**launches.get(jid,{'exclusive':None}),'exit_status':str(j.get('exit_status.txt','')).strip(),'packets':[]}
   for p in j['packets']:
    jj['packets'].append({'graph_or_fixture':p['packet'],'raw_log':p['path'],'primary_time_rows':len(p['times']),'median_groups':len(p['medians']),'gate_failures':p['failed_gates']})
   rr['jobs'].append(jj)
  found={j['job'].rsplit('-',1)[-1] for j in run['jobs']}
  for jid,li in launches.items():
   if jid not in found:rr['submitted_without_logs'].append({'job':jid,**li,'status':'CANCELLED_PENDING' if jid=='10887790' else 'not verified'})
  if run['run']=='state-reuse-20261007-01':rr['state']='compile_failed_TR_macro'
  if run['run']=='order-balance-20261007-01':rr['state']='superseded_before_measurement_diagnostic_counter_revision'
  f['lineage'].append(rr)
 out['families'].append(f)
(P/'coverage_oct07.json').write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding='utf8')
print(json.dumps({k:v for k,v in out.items() if k!='families'},ensure_ascii=False))
print('families',len(out['families']),'runs',sum(f['runs'] for f in out['families']),'jobs',sum(f['jobs'] for f in out['families']),'packets',sum(f['packets'] for f in out['families']))
