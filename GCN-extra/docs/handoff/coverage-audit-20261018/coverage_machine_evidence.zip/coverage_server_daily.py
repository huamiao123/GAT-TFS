import json,re,collections,datetime
from pathlib import Path
base=Path(__file__).parent
d=json.loads((base/'coverage_server_inventory.json').read_text(encoding='utf8'));ev=d['events']
def category(e):
 k=e.get('kind','').lower();s=e.get('status','');i=e['id'].lower();v=k+' '+i
 if s=='SUBMITTED' or 'submission' in k:return 'submission_event'
 if 'build' in k or s=='FAILED_BUILD_RETAINED':return 'build_event'
 if any(x in k for x in ['correction','issue','resolution','scheduler','cancellation','clarification']) or s in ['CANCELLED','CANCELLED_PENDING','CANCELLED_IMPLEMENTATION']:return 'issue_or_control_event'
 if any(x in v for x in ['analysis','reconcil','interpretation','delivery','report','postprocessing','publication','archive','research-model','current-summary','deep-review']):return 'analysis_or_report_event'
 if e.get('job_id') or e.get('job') or (e.get('exit_status') is not None and s in ['PASS','FAILED']):return 'execution_event'
 return 'plan_or_other_event'
daily=collections.defaultdict(collections.Counter)
jobsets=collections.defaultdict(set)
classified=[]
for e in ev:
 dt=datetime.datetime.fromisoformat(e['date'].replace('Z','+00:00'))
 day=dt.astimezone(datetime.timezone(datetime.timedelta(hours=8))).date().isoformat()
 c=category(e);daily[day][c]+=1;daily[day]['all_events']+=1
 job=e.get('job_id',e.get('job'))
 if job is not None:
  if isinstance(job,(str,int)):jobsets[day].add(str(job))
 row=dict(e);row['coverage_date_china']=day;row['coverage_category']=c;classified.append(row)
for day,co in sorted(daily.items()):print(day,dict(co),'unique_referenced_jobids',len(jobsets[day]))
ids=collections.Counter(e['id'] for e in ev)
print('DUPLICATE_IDS',[(x,n) for x,n in ids.items() if n>1]);print('TOTAL',dict(sum(daily.values(),collections.Counter())))
(base/'coverage_server_event_classification.json').write_text(json.dumps({'definition':'Event categories inferred deterministically from kind/status/id; not count of scientific experiments. China timezone. Job IDs referenced per day, not number of new jobs or completed benchmarks.','daily':{k:dict(v,unique_referenced_jobids=len(jobsets[k])) for k,v in sorted(daily.items())},'events':classified},indent=2,ensure_ascii=False),encoding='utf8')
