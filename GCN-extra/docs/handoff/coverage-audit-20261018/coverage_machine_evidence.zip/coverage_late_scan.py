from pathlib import Path
import json,re,collections,difflib,hashlib,statistics
R=Path('C:/Users/花喵/tmp/tfs18/results/crosslayer-fusion-20261008/runs')
P=Path('C:/Users/花喵/tmp/tfs_deep_review_20261018')
out=[]
for run in sorted(R.iterdir()):
 if not run.is_dir() or not run.name.startswith(('frontier','recompute','source-partition')):continue
 rec={'run':run.name,'files':[],'logs':[],'events':[],'sources':[],'records':[]}
 for f in sorted(run.rglob('*')):
  if not f.is_file():continue
  rel=str(f.relative_to(run));rec['files'].append(rel)
  if ('source_snapshot' in rel or 'source/' in rel) and f.suffix in ('.cpp','.hpp','.py','.sh'):
   rec['sources'].append({'path':rel,'sha256':hashlib.sha256(f.read_bytes()).hexdigest(),'size':f.stat().st_size})
  if f.name in ('event.json','recovery_event.json','submission_event.json'):
   try:rec['events'].append({'path':rel,'value':json.loads(f.read_text(encoding='utf8'))})
   except:pass
  if (f.suffix in ('.log','.err') or 'stderr' in f.name or f.name in ('build.log','compile.log')) and 'disassembly' not in f.name and f.stat().st_size<20000000:
   lines=f.read_text(encoding='utf8',errors='replace').splitlines();tags=collections.Counter();errors=[]
   for ln,line in enumerate(lines,1):
    tag=line.split(' ',1)[0] if line else ''
    fields=dict(re.findall(r'(\w+)=([^\s]+)',line))
    if re.fullmatch('[A-Z][A-Z_0-9]*',tag) and fields:
     tags[tag]+=1;rec['records'].append({'path':rel,'line':ln,'tag':tag,**fields,'raw':line})
    if re.search(r'error:|undefined reference|Traceback|Error:|not found|cannot |No such|FAILED|AssertionError|Killed|terminate called|Aborted|Segmentation',line,re.I):
     errors.append({'line':ln,'text':line,'context':lines[max(0,ln-2):min(len(lines),ln+3)]})
   if lines:rec['logs'].append({'path':rel,'lines':len(lines),'tags':dict(tags),'errors':errors,'tail':lines[-3:]})
 out.append(rec)
(P/'coverage_late_raw.json').write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding='utf8')
for r in out:
 print(r['run'],'files',len(r['files']),'sources',len(r['sources']),'records',len(r['records']))
 for f in r['logs']:
  if '/oracle/' in f['path'] or '/selftest/' in f['path']:continue
  if f['errors']:print(' ',f['path'],[(e['line'],e['text'][:200]) for e in f['errors'][:5]])
  if f['tags']:print(' ',f['path'],f['tags'])
