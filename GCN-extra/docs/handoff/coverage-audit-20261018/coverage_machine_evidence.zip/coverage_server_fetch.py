import subprocess,json,base64,time
from pathlib import Path
base=Path(__file__).parent
code=r'''
import os,json,time
from pathlib import Path
root=Path('/home/huangjianqiang_group/hdacp1/data/wzh/GCN-extra')
files=[];dirs=[]
for p,ds,fs in os.walk(root):
 for d in ds: dirs.append(str((Path(p)/d).relative_to(root)))
 for f in fs:
  q=Path(p)/f
  try:
   s=q.stat();files.append({'path':str(q.relative_to(root)),'size':s.st_size,'mtime':s.st_mtime})
  except Exception as e:files.append({'path':str(q.relative_to(root)),'error':str(e)})
events={}
for q in (root/'docs').rglob('*'):
 if q.is_file() and ('events' in q.name or q.name=='CURRENT_HANDOFF.md'):
  try:events[str(q.relative_to(root))]=q.read_text()
  except Exception as e:events[str(q.relative_to(root))]=str(e)
print(json.dumps({'root':str(root),'time_utc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),'files':files,'directories':dirs,'event_files':events}))
'''
b64=base64.b64encode(code.encode()).decode()
cmd='python3 -c "import base64;exec(base64.b64decode(\''+b64+'\'))"'
r=subprocess.run(['ssh','hdacp1@176.0.250.88',cmd],capture_output=True,timeout=120)
(base/'server_inventory_raw.json').write_bytes(r.stdout)
(base/'server_inventory_fetch_stderr.txt').write_bytes(r.stderr)
print('returncode',r.returncode,'stdout',len(r.stdout),'stderr',r.stderr.decode(errors='replace'))
data=json.loads(r.stdout)
print('files',len(data['files']),'dirs',len(data['directories']),'events',list(data['event_files']))
