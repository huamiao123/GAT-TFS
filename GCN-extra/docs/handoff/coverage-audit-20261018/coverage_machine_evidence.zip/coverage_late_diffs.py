from pathlib import Path
import difflib,json
R=Path('C:/Users/花喵/tmp/tfs18/results/crosslayer-fusion-20261008/runs')
P=Path('C:/Users/花喵/tmp/tfs_deep_review_20261018')
groups=[('frontier-certificate-20261008-*',['run_certificate.py','certificate_job.sh','frontier_certificate.cpp']),('recompute-audit-20261008-*',['run.py','stage.py','recompute_scan.cpp']),('recompute-window-20261008-*',['run.py','window_scan.cpp']),('recompute-window-kernel-build-*',['recompute_window_kernel.cpp']),('recompute-window-parallel-build-*',['recompute_window_parallel.cpp','recompute_window_kernel.cpp']),('recompute-window-adaptive-build-*',['recompute_window_adaptive.cpp']),('source-partition-weighted-build-*',['source_partition_weighted.cpp','source_partition_hot.cpp'])]
sections=[];meta=[]
for glob,names in groups:
 runs=sorted(R.glob(glob))
 for prev,nxt in zip(runs,runs[1:]):
  ps=prev/'source_snapshot';ns=nxt/'source_snapshot'
  files=sorted({p.name for p in ps.glob('*') if p.suffix in ('.py','.cpp','.hpp','.sh')}|{p.name for p in ns.glob('*') if p.suffix in ('.py','.cpp','.hpp','.sh')})
  for name in files:
   a=ps/name;b=ns/name
   aa=a.read_text(encoding='utf8').splitlines() if a.exists() else []
   bb=b.read_text(encoding='utf8').splitlines() if b.exists() else []
   diff=list(difflib.unified_diff(aa,bb,fromfile=prev.name+'/'+name,tofile=nxt.name+'/'+name,n=2))
   meta.append({'before':prev.name,'after':nxt.name,'file':name,'same':not diff,'diff_lines':len(diff)})
   if diff:sections.append('\n'.join(diff))
(P/'coverage_late_diffs.txt').write_text('\n\n'.join(sections),encoding='utf8')
(P/'coverage_late_diff_manifest.json').write_text(json.dumps(meta,ensure_ascii=False,indent=2),encoding='utf8')
print('diff sections',len(sections),'lines',sum(len(s.splitlines()) for s in sections))
for x in meta:
 if not x['same']:print(x)
