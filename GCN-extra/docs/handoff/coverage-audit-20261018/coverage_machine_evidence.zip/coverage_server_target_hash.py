import subprocess,json,base64,hashlib,collections
from pathlib import Path
base=Path(__file__).parent
d=json.loads((base/'server_inventory_raw.json').read_text(encoding='utf8'))
allowed={'.cpp','.hpp','.h','.c','.py','.sh','.md','.json','.csv','.log','.txt'}
prefixes=['experiments/','results/p2-overlap-20261005/','results/p2-overlap-20261005-v2/']
runprefixes=['runs/feature-precision-ablation-','runs/projection-window-build-','runs/state-reuse-','runs/delayed-residual-gate-','runs/onemkl-bf16-twostep-packed-']
paths=[x['path'] for x in d['files'] if (any(x['path'].startswith(p) for p in prefixes) or (any(x['path'].startswith(p) for p in runprefixes) and '/source_snapshot/' in x['path'])) and Path(x['path']).suffix in allowed]
code='import json,hashlib\nfrom pathlib import Path\nroot=Path("/home/huangjianqiang_group/hdacp1/data/wzh/GCN-extra")\npaths='+repr(paths)+'''
out=[]
for s in paths:
 try:
  b=(root/s).read_bytes();out.append({'path':s,'size':len(b),'sha256':hashlib.sha256(b).hexdigest()})
 except Exception as e:out.append({'path':s,'error':str(e)})
print(json.dumps(out))
'''
b64=base64.b64encode(code.encode()).decode()
r=subprocess.run(['ssh','hdacp1@176.0.250.88','python3 -'],input=code.encode(),capture_output=True,timeout=90)
(base/'coverage_server_target_hashes.json').write_bytes(r.stdout)
print('rc',r.returncode,'bytes',len(r.stdout),'paths',len(paths),'stderr',r.stderr.decode(errors='replace'),flush=True)
data=json.loads(r.stdout)
sizes={x['size'] for x in data if 'size' in x};hashes=collections.defaultdict(list)
for p in (base.parent/'tfs18').rglob('*'):
 if p.is_file() and p.stat().st_size in sizes:hashes[hashlib.sha256(p.read_bytes()).hexdigest()].append(str(p.relative_to(base.parent/'tfs18')).replace('\\','/'))
for row in data:row['github_identical_paths']=hashes.get(row.get('sha256'),[])
(base/'coverage_server_target_hash_matches.json').write_text(json.dumps(data,indent=2),encoding='utf8')
print('server_hashed',len(data),'matched',sum(bool(x['github_identical_paths']) for x in data))
