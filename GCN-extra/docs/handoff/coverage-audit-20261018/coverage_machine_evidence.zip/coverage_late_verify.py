from pathlib import Path
import json,statistics,math,difflib
P=Path('C:/Users/花喵/tmp/tfs_deep_review_20261018');R=Path('C:/Users/花喵/tmp/tfs18/results/crosslayer-fusion-20261008/runs')
d=json.loads((P/'coverage_late_raw.json').read_text(encoding='utf8'))
out={'timing_groups':[],'partition_checks':[],'event_raw_checks':[],'structural_json_checks':[],'source_diffs':[]}
for run in d:
 pending=[]
 for rec in run['records']:
  if rec['tag'] in ('PAR_RUN','ADAPT_RUN'):pending.append(rec)
  if rec['tag'] in ('PAR_RESULT','ADAPT_RESULT'):
   vals={k:[float(x[k]) for x in pending] for k in ['baseline_ms','candidate_ms']}
   check={'run':run['run'],'path':rec['path'],'line':rec['line'],'graph':rec.get('graph'),'order':rec.get('order'),'mode':rec.get('mode'),'batch':rec.get('source_batch_blocks'),'samples':len(pending),'exact':rec.get('exact'),'raw':pending}
   for k,v in vals.items():
    if not v:continue
    check[k+'_true_median']=statistics.median(v);check[k+'_upper_median']=sorted(v)[len(v)//2]
    key=k.replace('_ms','_median_ms');reported=float(rec[key]);check[key+'_reported']=reported
    check[key+'_matches_true']=math.isclose(reported,statistics.median(v),abs_tol=1e-7)
    check[key+'_matches_upper']=math.isclose(reported,sorted(v)[len(v)//2],abs_tol=1e-7)
   if vals['candidate_ms'] and statistics.median(vals['candidate_ms'])>0:check['speedup_true_median']=statistics.median(vals['baseline_ms'])/statistics.median(vals['candidate_ms'])
   out['timing_groups'].append(check);pending=[]
  if rec['tag']=='PARTITION':
   x={'run':run['run'],'path':rec['path'],'line':rec['line'],'order':rec.get('order'),'n':rec.get('n'),'e':rec.get('e'),'edge_check':int(rec['edge_check'])==int(rec['e'])}
   expected=int(rec['total_unique_sources'])/int(rec['global_sources'])
   x['duplication_ok']=abs(expected-float(rec['duplication']))<1e-8
   if 'weighted_duplication' in rec:
    x['weighted_denominator']='global_weight=sum(row_degree over globally consumed sources), not E; absent from log, needs CSR'
    x['weighted_ratio_vs_E_matches']=abs(int(rec['weighted_total'])/int(rec['e'])-float(rec['weighted_duplication']))<1e-8
   out['partition_checks'].append(x)
 for event in run['events']:
  for key in ('results','gates'):
   rows=event['value'].get(key)
   if isinstance(rows,list) and all(isinstance(x,str) for x in rows):
    raws={x['raw'] for x in run['records']}
    out['event_raw_checks'].append({'run':run['run'],'event':event['path'],'key':key,'rows':len(rows),'not_in_raw':sum(x not in raws for x in rows)})
 for f in (R/run['run']).glob('compute-*/result/*.json'):
  if f.name=='audit.json':continue
  x=json.loads(f.read_text(encoding='utf8'))
  checks=[]
  for w in x.get('windows',[]):
   if 'extra_edge_visit_ratio' in w:checks.append(abs(w['extra_first_layer_edge_visits']/x['e']-w['extra_edge_visit_ratio'])<1e-7)
  out['structural_json_checks'].append({'run':run['run'],'file':str(f.relative_to(R)),'graph':x.get('graph'),'status':x.get('status'),'window_rows':len(x.get('windows',[])),'ratio_checks':len(checks),'ratios_pass':all(checks)})
pairs=[('frontier-certificate-20261008-01','frontier-certificate-20261008-02','frontier_certificate.cpp','frontier_certificate.cpp'),('frontier-certificate-20261008-01','frontier-certificate-20261008-02','run_certificate.py','run_certificate.py'),('source-partition-build-20261008-210228','source-partition-weighted-build-20261008-232004','source_partition_analyzer.cpp','source_partition_weighted.cpp'),('source-partition-weighted-build-20261008-232004','source-partition-weighted-build-20261008-232709','source_partition_weighted.cpp','source_partition_hot.cpp')]
for a,b,x,y in pairs:
 aa=next((R/a/'source_snapshot').rglob(x));bb=next((R/b/'source_snapshot').rglob(y));diff=list(difflib.unified_diff(aa.read_text(encoding='utf8').splitlines(),bb.read_text(encoding='utf8').splitlines(),fromfile=a+'/'+x,tofile=b+'/'+y,n=2))
 out['source_diffs'].append({'before':str(aa.relative_to(R)),'after':str(bb.relative_to(R)),'same':not diff,'diff':diff})
(P/'coverage_late_checks.json').write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding='utf8')
print('timing groups',len(out['timing_groups']),'raw paired rows',sum(x['samples'] for x in out['timing_groups']))
print('summary not true median',sum(not x.get('baseline_median_ms_matches_true',True) or not x.get('candidate_median_ms_matches_true',True) for x in out['timing_groups']))
print('partition records',len(out['partition_checks']),'failed edge/unique checks',sum(not(x['edge_check'] and x['duplication_ok']) for x in out['partition_checks']))
print('event raw rows',sum(x['rows'] for x in out['event_raw_checks']),'missing',sum(x['not_in_raw'] for x in out['event_raw_checks']))
print('structural windows',sum(x['window_rows'] for x in out['structural_json_checks']),'failed ratios',sum(not x['ratios_pass'] for x in out['structural_json_checks']))
for x in out['timing_groups']:
 if 'adaptive' in x['run']:print({k:v for k,v in x.items() if k not in ('raw','path')})
