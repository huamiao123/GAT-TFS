import json,collections,re
from pathlib import Path
base=Path(__file__).parent
d=json.loads((base/'coverage_server_inventory.json').read_text(encoding='utf8'))
h=json.loads((base/'coverage_server_target_hash_matches.json').read_text(encoding='utf8'))
daily=json.loads((base/'coverage_server_event_classification.json').read_text(encoding='utf8'))
sf={x['path']:x for x in d['server_files']};gp=set(d['github_paths']);root='/home/huangjianqiang_group/hdacp1/data/wzh/GCN-extra/'
names=sorted({p.split('/')[1] for p in sf if p.startswith('experiments/')})
def count(prefix,paths):return sum(p.startswith(prefix) for p in paths)
units=[]
early={'feature_precision_8aeef16','journal_decoupling_a3_20261004'}
oct7={x for x in names if x.endswith('20261007')}
oct78=oct7|{'access_prefetch_20261008','event_trace_20261008'}
oct78_limits={
'grouping_balance_20261007':'已补核1 run/8 job/8100主计时。剩余17图真实CSR minhash/LRU机会统计独立重放与真实缓存成因。',
'order_balance_20261007':'已补核2 run/5 job/7410主计时，含两层3×3顺序与两形状。剩余全PMU线程计数重算及实际应用精度。',
'state_reuse_20261007':'已补核01编译、02/03 subnormal、04 NaN失败到05修复；5 run/13 job/5160主计时。剩余完整热循环反汇编逐指令审查及完整输入精度证明。',
'pair_plan_20261007':'已补核1 run/12 job/8850主计时，含动态/静态exact、真实/合成图cohort。剩余17图配对元数据本地重建及完整汇编因果审查。',
'pair_order_control_20261007':'已补核1 run/3 job/450主计时及同地址/同成员顺序控制。剩余硬件成因与真实图泛化；本轮实验仅synthetic。',
'order_share_factorial_20261007':'已补核1 run/7 job/2730主计时、三个预定seed及推广门槛。剩余全seed统计显著性与更多真实图；原推广门槛未过。',
'access_prefetch_20261008':'已补核1 run/7 job/2730主计时、PF0/1/8目标多重集和scope前奏。剩余缓存层级/MLP因果及最优预取距离；未搜索最优距离。',
'event_trace_20261008':'已补核1 run/7 job/1680主计时、builder/validator/三replay及malformed gates。剩余本机全真实CSR独立replay和完整codegen比较。',
}
projection={'avx_amx_overlap_p2_20261005','delayed_residual_gate_20261005','journal_followup_p3_p4_20261005','journal_grouping_p1_20261005'}
baseline={'full_degree_sort_ablation_20261015','h_panel_reuse_20261014','onemkl_amx_audit_20261015','onemkl_bf16_interleave_20261015','onemkl_bf16_twostep_20261015','onemkl_bf16_twostep_packed_20261015'}
remaining={
'feature_precision_8aeef16':'17:02、21:29、21:40三版必须分列；旧first-touch混杂轮不能用当前修正版替代。29项无HEAD副本名单含旧runtime/driver/protocol。10/4补核由coverage_oct04报告说明。',
'journal_decoupling_a3_20261004':'21:56、22:05、22:14三build及各smoke分列；最终A3的2890计时不能代替独立projection-window的2720计时。',
'avx_amx_overlap_p2_20261005':'本轮已核P2 v1/v2 summary相同、decoder修复事件；旧analyze_overlap.py与HEAD无同内容副本。历史v1误解码不能当独立性能重跑。',
'delayed_residual_gate_20261005':'11:20的事件自述不能解释真实错误：preflight改RUN导致logs/logs/node.txt缺失，kernel未运行；D1数值反例来自11:22成功执行。详见coverage_misc_versions补核，以交付证据为准。',
'journal_followup_p3_p4_20261005':'P3 residual-broad、P4 selective-shape 12:29及12:34版本不能合并；12:34新增逐层混合策略并改回随机输入，不只是build修复。详见coverage_misc_versions补核，以交付证据为准。',
'journal_grouping_p1_20261005':'smoke/synthetic/focus/validation均已在旧附件概述；每个source snapshot和原始逐线程timer未逐行人工阅读。',
'full_degree_sort_ablation_20261015':'smoke10968050固定32核断言失败、10968053缺rg提取失败、后续修复成功需分别记账；旧附件主要深核成功性能轮。',
'onemkl_bf16_twostep_packed_20261015':'16:31失败driver没有HEAD同内容副本；16:32/16:34版本及10973279取消备份提交需独立核源。旧附件分析成功性能。',
'state_reuse_20261007':'01宏展开编译失败、02/03 subnormal语义失败、04 NaN语义失败、05最终通过；不能只读05。具体补核见coverage_oct07。',
'frontier_structure_20261008':'structure、certificate01链接失败、certificate02修复、state-search均是不同阶段；上轮聚焦结论，尚缺逐版本文件级深核标记。',
'recompute_audit_20261008':'01/02失败、03过慢取消、04仅准备、05 C++成功及两次analysis修订均应分列；旧附件审过关键模型错误，不等于每版完整核毕。',
'recompute_window_20261008':'01、02失败、03、04及retry04分析；需逐版本核验新旧窗口工作量与数值gate，不能仅以04覆盖。',
'recompute_window_kernel_20261008':'19:37/19:39构建失败，19:41修复及10900289、两次sweep；旧附件深核有效prototype，未逐个失败compile.log说明。',
'recompute_window_parallel_20261008':'20:21/21:19构建失败、20:24/21:22修复及共享/独享/跨图四类run；保留失败而不并入性能样本。',
'recompute_window_batch_20261008':'22:17/22:22/22:26/22:28四run，空结果与完整结果并存；旧附件已核22:28的36结果及FAILED计数错误，其他版未同深度复核。',
'recompute_window_interleave_20261008':'23:05/23:09/23:14/23:36四run与失败build分列；此处interleave为计时顺序，不自动等于NUMA interleave。',
'recompute_window_adaptive_20261008':'23:37/23:42两版build及run；旧附件已发现赋baseline时间和memcpy的回退伪证据，但两版全部逐次输出未完整重算。',
'source_partition_weighted_20261008':'weighted、hot、heldout、roadusa不同阶段；hot_src初始化错误已审，但完整stage-by-stage对照仍需记录。',
'source_partition_hot_20261008':'hot_source初始化机制已审；对应weighted-run与hot-run映射仍应独立保留。',
}
for name in names:
 p='experiments/'+name+'/';arch='results/crosslayer-fusion-20261008/'+p
 hp=p if any(x.startswith(p) for x in gp) else arch
 if name in early:old='audit_projection.md';supp='coverage_oct04（由该审阅自述深度）'
 elif name in oct78:old='audit_crosslayer.md';supp='coverage_oct07.md：源码版本、失败链、全量保存主计时已补核'
 elif name in projection:old='audit_projection.md';supp='本轮仅目录/事件/定向hash；P2额外核v1/v2'
 elif name in baseline:old='audit_order_baselines.md';supp='本轮目录/事件/定向hash'
 else:old='audit_crosslayer.md';supp='本轮目录/事件/定向hash'
 rows=[x for x in h if x['path'].startswith(p)]
 rem=remaining.get(name,'旧附件覆盖该族关键实现/结果；本轮未新增所有source_snapshot、失败重跑和全部raw样本逐版本深审证明。')
 if name in oct78:rem=oct78_limits[name]+' 见[coverage_oct07.md](coverage_oct07.md)。'
 elif name=='feature_precision_8aeef16':
  supp='coverage_oct04.md：三个build、取消链、最终3600计时及配置全量核对完成'
  rem='最终native FP32 parallel-static copy已确认，撤回旧附件首触误读；早期取消partial不作正式性能统计。页面完全一致/纯decode成本仍未证明。见[coverage_oct04.md](coverage_oct04.md)。'
 elif name=='journal_decoupling_a3_20261004':
  supp='coverage_oct04.md：三次build diff、smoke、来源链完成；2890计时继承上一轮全量对账'
  rem='A3与独立S/M的2720计时已分清；没有逐条人工解释全部PMU/profile或重跑硬件因果。见[coverage_oct04.md](coverage_oct04.md)。'
 elif name.endswith('20261008'):
  supp+='；失败/修复链补审见coverage_late_versions（进行中，以交付报告为准）'
  rem+=' 补审任务见coverage_late_versions，未交付前不标为完成。'
 elif name.endswith('20261005') or name.endswith('20261015'):
  supp+='；失败/修复链补审见coverage_misc_versions（进行中，以交付报告为准）'
  rem+=' 补审任务见coverage_misc_versions，未交付前不标为完成。'
 units.append({'unit':name,'unit_type':'experiment_source_directory','canonical_server_path':root+p,'head_path':hp,'server_files':count(p,sf),'head_files_at_mapping':count(hp,gp),'previous_deep_review_reference':old,'current_review_scope':supp,'remaining':rem,'hashed_working_text_files':len(rows),'hashed_working_text_files_with_head_identical_copy':sum(bool(x['github_identical_paths']) for x in rows)})
for unit,sp,hp in [('paper-method','runs/paper-method-','src/paper_methods_kernels.hpp'),('paper-cache-control','runs/paper-cache-','scripts/build_paper_cache_control.sh'),('projection-window-independent','runs/projection-window-','src/projection_window_kernels.hpp')]:
 n={'paper-method':'正式2720、含smoke3040','paper-cache-control':'正式850、含smoke950','projection-window-independent':'正式2720'}[unit]
 units.append({'unit':unit,'unit_type':'root_source_and_run_family','canonical_server_path':root+sp+'*','head_path':hp,'server_files':count(sp,sf),'head_files_at_mapping':count(sp,gp),'previous_deep_review_reference':'audit_projection.md','current_review_scope':'coverage_oct04.md：源码、控制/取消/构建来源链、'+n+'计时全量对账完成','remaining':'主要来源与raw已补核；没有人工解释所有重复PMU/profile，没有重跑性能/证明硬件因果。见[coverage_oct04.md](coverage_oct04.md)。'})
run_names=sorted({p.split('/')[1] for p in sf if p.startswith('runs/') and p.count('/')>=2})
runs=[]
for name in run_names:
 p='runs/'+name+'/';arch='results/crosslayer-fusion-20261008/'+p
 review='not certified by this inventory; consult later-version subreview if applicable'
 if name.startswith(('grouping-balance-','order-balance-','state-reuse-','pair-plan-','pair-order-control-','order-share-factorial-','access-prefetch-','event-trace-')):review='coverage_oct07.md: source/run lineage and all saved primary timing audited; assembly/CSR replay limitations retained'
 elif name.startswith(('paper-method-','paper-cache-','projection-window-','feature-precision-','journal-a3-')):review='coverage_oct04.md: source/control lineage and specified raw timing audited; cancelled partial data not formal performance and full PMU causality not claimed'
 runs.append({'run':name,'server_path':root+p,'server_files':count(p,sf),'head_same_path_files':count(p,gp),'head_crosslayer_archive_files':count(arch,gp),'scope':'container_or_attempt_not_scientific_experiment','individual_deep_review':review})
unmatched=[x for x in h if not x['github_identical_paths']]
failed=[x for x in d['events'] if x.get('status') in ['FAILED','FAILED_BUILD_RETAINED','CANCELLED','CANCELLED_IMPLEMENTATION','RESOLVED_FOR_REBUILD','ROOT_CAUSE_CONFIRMED','INVESTIGATING_COMPILER_FP_ASSUMPTIONS']]
for e in failed:
 if e['id'].startswith(('state-reuse','pair-plan')):e['coverage_review_status']='completed within coverage_oct07.md scope; residual limitations retained'
 elif e['id'].startswith('feature-precision'):e['coverage_review_status']='completed within coverage_oct04.md scope; cancelled partial timings excluded from formal performance'
 elif '20261008' in e['id'] or e['id'].startswith('frontier-certificate'):e['coverage_review_status']='await coverage_late_versions delivery'
 else:e['coverage_review_status']='await coverage_misc_versions delivery'
 if e['id']=='logs' and e.get('job_id')=='10869361':e['coverage_correction']='Actual failure is preflight RUN-path rewrite leading to missing logs/logs/node.txt; kernel not run. Original event D1-expected-failure wording is incorrect; D1 counterexample belongs to successful112212. See coverage_misc_versions.'
out={'definitions':{'unit':'33 current source directories plus main/cache/projection root families =36 organizational units, not36 independent experiments','run':'140 top-level containers including submit/build/analyze/publication copies; nested graph/job records differ','event':'438 chronological events/437 distinct IDs, includes submissions/builds/failures/corrections; no equivalence to experiment count','deep_review':'requires exact source version + launcher + raw samples + numerical/statistical audit, not certified by inventory/hash'},'units':units,'runs':runs,'daily':daily['daily'],'unmatched_selected_content':unmatched,'failed_or_corrected_events':failed,'limits':['No kernel, compilation, Slurm submission, or remote writes.','All 36052 server files inventoried by path/size/mtime; only856 selected text contents hash-compared;827 have byte-identical HEAD copies.','Attempt to hash all nonbinary server evidence timed out after180 seconds without a complete dataset; excluded from claims.','Neither path inventory nor SHA match proves a human/deep semantic review.']}
(base/'coverage_server.json').write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding='utf8')
lines=['# 服务器实验覆盖核查：从10月4日起逐级对账','', '本报告只证明目录、事件、特定内容副本的覆盖，不证明所有实验版本都已完成源码与原始样本深审。服务器根目录：`'+root+'`；GitHub固定提交：`9369b9e0491d59e328a99153b6d97314c62285da`。','',
'本轮只读，无编译、kernel执行、Slurm提交或远端写入。读取了当前wzh/AGENTS.md和tfs-research-engineering/SKILL.md。', '',
'实际清单：36,052个服务器文件，33个experiments直接目录、140个runs直接容器、17个results直接目录、438条事件/437个不同事件ID。GitHub HEAD为16,442文件、14个experiments直接目录、29个runs直接目录、15个results直接目录。19个experiment源码族搬入了crosslayer归档，不能只数一级results。', '',
'140个run容器也不是140次独立科学实验：其中publication-crosslayer-20261013-review单独含13,308份发布副本。438条事件含构建、提交、执行、失败、分析、交接；recompute-audit-prepared-20261008的ID重复两次。', '',
'定向内容对账：856个文本文件覆盖全部33个工作experiments文本、P2分析v1/v2及选定历史source_snapshot；827份能在HEAD找到逐字相同副本，29份不能。全库非二进制哈希尝试180秒超时，没有完整结果，不计入验证。','',
'补审状态更新：10/4见[coverage_oct04.md](coverage_oct04.md)，已完成初始S/M 2720与最终feature 3600等原始计时核对并纠正首触误读；10/7–8八族见[coverage_oct07.md](coverage_oct07.md)，13 run/62 job/37110主计时已全量补核。两份子审保留其自身PMU、汇编、真实CSR重放与因果限制。本台账不再将这些已完成链标成“只看事件”。','',
'## 逐日事件（中国时区；不是实验数量）','', '|日期|全部事件|构建|提交|执行记录|分析/报告|控制/问题|准备/其他|引用不同job标识|','|---|---:|---:|---:|---:|---:|---:|---:|---:|']
for day,row in daily['daily'].items():lines.append('|'+day+'|'+'|'.join(str(row.get(k,0)) for k in ['all_events','build_event','submission_event','execution_event','analysis_or_report_event','issue_or_control_event','plan_or_other_event','unique_referenced_jobids'])+'|')
lines+=['','分类规则保存在coverage_server_daily.py与coverage_server_event_classification.json；执行记录可含本地轻量运行、数值、结构分析或失败，不可读作“成功性能实验”。job标识可能是build-163149，不是全为Slurm编号。','',
'## 36个组织单元逐项定位','', '路径均相对上述server root/HEAD的GCN-extra。旧附件一栏仅引述其覆盖范围，不为未列出的版本背书；coverage_oct04与coverage_oct07另有负责审阅。','', '|单元|服务器canonical相对路径|HEAD路径|旧附件|本轮与待补|','|---|---|---|---|---|']
for u in units:lines.append('|'+u['unit']+'|`'+u['canonical_server_path'].replace(root,'')+'`|`'+u['head_path']+'`|'+u['previous_deep_review_reference']+'|'+u['current_review_scope']+'；'+u['remaining']+'|')
lines+=['','## 已确认的版本差异与边界','',
'1. 10/4独立projection-window结果含17图、2720计时、1020数值gate、408同scope逐位gate、476profile逐位gate；后续A3/P0的2890条不能替代。当前GitHub仅保留该reconcile容器5文件，服务器26文件。coverage_oct04已完成17份原始methods.log与2720条表全量对账，零缺失。',
'2. feature-precision 17:02/21:29旧runtime与21:40修正版不同。21:29轮因FP32串行first-touch造成placement混杂被取消接受；原始结果保留而不得做强性能分母。旧runtime/driver/protocol没有HEAD逐字相同副本。',
'3. P2 results/p2-overlap-20261005和-v2为同一次性能记录的不同反汇编审计。已验证summary对象完全相同；v2用iced-x86修复objdump2.30不识别AMX的问题，不是另一轮性能实测。HEAD保留v2内容，旧analysis脚本仍只在服务器。',
'4. 10/7 state-reuse有01编译宏失败、02/03 subnormal语义失败、04 NaN语义失败、05最终通过。coverage_oct07已逐版补核这条链，并与另七族共37110计时全量对账。仍未重做全部热循环反汇编和全真实CSR本机重放。',
'5. 10/15 full-degree-sort两次smoke失败分别是固定32核affinity断言、节点缺rg日志提取；packed oneMKL首次构建用错CblasBIdentifier（应为CblasBMatrix）。失败不是性能反例，也不应被成功轮吞掉。','',
'## HEAD没有逐字副本的29个定向检查文件','', '这不是全库未上传文件总数，只是856项内容对账的确定差集。相同内容可能在多个旧文件中重复；机器清单保存每项SHA256。','']
for x in unmatched:lines.append('- `'+x['path']+'`')
lines+=['','## 失败/修复链及补审状态','', '事件的存在、路径和记录问题均已核实。state/pair链已由coverage_oct07补核，feature取消链由coverage_oct04补核；其余10/8版本与10/5、15版本分别等待coverage_late_versions、coverage_misc_versions交付。下表显式区分，不能仅据事件文本宣称全部compile.log或逐样本已审。','', '|事件|状态|证据|补审状态/事件自述问题（节选）|','|---|---|---|---|']
for e in failed:
 msg=str(e.get('reason',e.get('issues',''))).replace('|','/').replace('\n',' ')[:250]
 if e['id'].startswith(('state-reuse','pair-plan')):state='已补核：[coverage_oct07.md](coverage_oct07.md)。'
 elif e['id'].startswith('feature-precision'):state='已补核：[coverage_oct04.md](coverage_oct04.md)。'
 elif '20261008' in e['id'] or e['id'].startswith('frontier-certificate'):state='待coverage_late_versions交付。'
 else:state='待coverage_misc_versions交付。'
 if e['id']=='logs' and e.get('job_id')=='10869361':state+='已收到源码/日志补核纠正：本次为preflight路径错误、kernel未运行；下列“D1 expected”只是错误事件自述，D1反例出自112212成功运行。'
 lines.append('|'+e['id']+'|'+e['status']+'|`'+str(e.get('evidence','')).replace(root,'')+'`|'+state+msg+'|')
lines+=['','## 140个run容器完整索引','', 'HEAD同路径数=0不能直接推断未上传：存在改名、结果精简和crosslayer搬迁。最后一列仅列crosslayer已知搬迁；其他改名归档由内容哈希/来源manifest定位。没有把容器文件数当深审数量。','', '|run|服务器文件|HEAD同路径文件|HEAD crosslayer搬迁文件|','|---|---:|---:|---:|']
for r in runs:lines.append('|`'+r['run']+'`|'+str(r['server_files'])+'|'+str(r['head_same_path_files'])+'|'+str(r['head_crosslayer_archive_files'])+'|')
lines+=['','机器证据：coverage_server.json（36单元/140容器/29差集/失败链）、server_inventory_raw.json（所有路径及完整events）、coverage_server_inventory.json、coverage_server_event_classification.json、coverage_server_target_hash_matches.json、coverage_server_details.json。','']
(base/'coverage_server.md').write_text('\n'.join(lines),encoding='utf8')
print('units',len(units),'runs',len(runs),'failed_or_corrected',len(failed),'unmatched',len(unmatched),'mdbytes',(base/'coverage_server.md').stat().st_size)
