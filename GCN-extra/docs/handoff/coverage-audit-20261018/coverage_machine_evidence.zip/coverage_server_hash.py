import subprocess,json,base64,hashlib,collections
from pathlib import Path
base=Path(__file__).parent
code=r'''
import os,json,hashlib,time
from pathlib import Path
root=Path('/home/huangjianqiang_group/hdacp1/data/wzh/GCN-extra')
allowed={'.cpp','.hpp','.h','.c','.py','.sh','.md','.txt','.json','.jsonl','.csv','.log','.out','.sha256','.s','.tsv'}
data=[]
for p,ds,fs in os.walk(root):
 if 'runs/publication-crosslayer-20261013-review' in str(p):ds[:]=[];continue
 for f in fs:
  q=Path(p)/f
  if q.suffix not in allowed:continue
  try:
   h=hashlib.sha256()
   with q.open('rb') as inp:
    for chunk in iter(lambda:inp.read(1024*1024),b''):h.update(chunk)
   data.append({'path':str(q.relative_to(root)),'size':q.stat().st_size,'sha256':h.hexdigest()})
  except Exception as e:data.append({'path':str(q.relative_to(root)),'error':str(e)})
print(json.dumps(data))
'''
b64=base64.b64encode(code.encode()).decode()
r=subprocess.run(['ssh','hdacp1@176.0.250.88','python3 -c "import base64;exec(base64.b64decode(\''+b64+'\'))"'],capture_output=True,timeout=180)
(base/'coverage_server_hashes.json').write_bytes(r.stdout)
print('rc',r.returncode,'bytes',len(r.stdout),'stderr',r.stderr.decode(errors='replace'))
hashes=collections.defaultdict(list)
for p in (base.parent/'tfs18').rglob('*'):
 if p.is_file():hashes[hashlib.sha256(p.read_bytes()).hexdigest()].append(str(p.relative_to(base.parent/'tfs18')).replace('\\','/'))
data=json.loads(r.stdout)
for row in data:row['github_identical_paths']=hashes.get(row.get('sha256'),[])
(base/'coverage_server_hash_matches.json').write_text(json.dumps(data,indent=2),encoding='utf8')
print('server_hashed',len(data),'matched',sum(bool(x['github_identical_paths']) for x in data))
