from pathlib import Path,PurePosixPath
import tarfile,hashlib,json
base=Path(__file__).parent
dest=base.parent/'tfs18pre'
dest.mkdir(exist_ok=True)
tree=json.loads((base/'coverage_tree_precleanup.json').read_text(encoding='utf8'))
expected={x['path'][10:]:x for x in tree['tree'] if x['type']=='blob' and x['path'].startswith('GCN-extra/')}
seen=set();bad=[]
with tarfile.open(base/'coverage_precleanup.tar.gz','r:gz') as tar:
 for item in tar:
  parts=PurePosixPath(item.name).parts
  if len(parts)<3 or parts[1]!='GCN-extra' or not item.isfile():continue
  rel='/'.join(parts[2:])
  assert '..' not in parts
  b=tar.extractfile(item).read()
  digest=hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()
  assert rel in expected,rel
  if digest!=expected[rel]['sha']:bad.append(rel)
  p=dest.joinpath(*parts[2:]);p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b)
  seen.add(rel)
out={'commit':tree['sha'],'destination':str(dest),'files':len(seen),'missing':sorted(set(expected)-seen),'mismatches':bad}
(base/'coverage_history_restore.json').write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding='utf8')
print(json.dumps(out,ensure_ascii=True))
