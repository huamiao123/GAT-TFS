import pathlib,json
base=pathlib.Path(__file__).parent
p=base/'coverage_server.json'
d=json.loads(p.read_text(encoding='utf8'))
late=['frontier_structure_20261008','recompute_audit_20261008','recompute_window_20261008','recompute_window_kernel_20261008','recompute_window_parallel_20261008','recompute_window_batch_20261008','recompute_window_interleave_20261008','recompute_window_adaptive_20261008','source_partition_audit_20261008','source_partition_weighted_20261008','source_partition_hot_20261008']
misc=['delayed_residual_gate_20261005','journal_followup_p3_p4_20261005','full_degree_sort_ablation_20261015','onemkl_bf16_twostep_packed_20261015']
updates={}
for u in d['units']:
    name=u['unit']
    if name in late:
        desc='已由coverage_late_versions.md补核52容器的实际错误/源码版本及372对原始时间；01生命周期模型等实质变更与工程失败分开。缺233639构建日志、batch外层验收脚本及独立CSR/PMU因果验证的限制保留。'
        ref='coverage_late_versions.md'
    elif name in misc:
        desc='已由coverage_misc_versions.md补核实际启动/编译/取消记录、源码差异与已有graph结果；P3启动失败、P4新增混合策略、FULL部分完成与packed修复分别记录。FULL旧失败launcher完整副本缺失限制保留。'
        ref='coverage_misc_versions.md'
    else:continue
    u['current_review_scope']=desc
    u['subsequent_version_audit']=ref
    u['remaining']='See explicit limitations in '+ref+'; no new kernel execution or full disassembly/real-CSR replay.'
    updates[name]=desc
d['reconciled_reports']=['coverage_history.md','coverage_oct04.md','coverage_oct07.md','coverage_misc_versions.md','coverage_late_versions.md']
p.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
p=base/'coverage_server.md';s=p.read_text(encoding='utf8');lines=[]
for line in s.splitlines():
    if line.startswith('|'):
        cols=line.split('|')
        if len(cols)==7 and cols[1] in updates:
            cols[-2]=updates[cols[1]];line='|'.join(cols)
    lines.append(line)
s='\n'.join(lines)+'\n'
s=s.replace('## 尚未逐项深审的失败/修复链（事件已读取）','## 失败/修复事件索引（最终核验见分审）')
s=s.replace('下列事件的存在、路径和记录问题已核实；不能仅据事件文本宣称已重读每份compile.log或逐样本复算。已由其他补核完成的项，以其独立报告覆盖状态更新。','下列保留事件原始自述，不能将自述原因直接当作实际错误归因。八族版本见coverage_oct07，10/5与10/15见coverage_misc_versions，10/8后半见coverage_late_versions；上述分审已补读实际错误和源码差异。具体缺证以分审列出的限制为准。')
s=s.replace('后续10/8失败版本以coverage_late_versions.md为准','后续10/8失败版本以coverage_late_versions.md为准')
p.write_text(s,encoding='utf8')
print('Reconciled',len(updates),'organization-unit version-audit references')
