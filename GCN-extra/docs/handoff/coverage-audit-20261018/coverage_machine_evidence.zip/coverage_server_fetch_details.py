import subprocess,json,base64
from pathlib import Path
base=Path(__file__).parent
code=r'''
import json
from pathlib import Path
root=Path('/home/huangjianqiang_group/hdacp1/data/wzh/GCN-extra')
paths=['docs/PROJECTION_WINDOW_RESULTS_20261004.md','docs/PROJECTION_WINDOW_PROTOCOL_20261004.md','results/p2-overlap-20261005-v2/event.json','results/p2-overlap-20261005-v2/decoder_issue_event.json','results/p2-overlap-20261005/event.json','results/p2-overlap-20261005-v2/summary.json','results/p2-overlap-20261005/summary.json','runs/feature-precision-ablation-20261004-212957/logs/diagnostic-10867476/event.json','runs/projection-window-reconciled-20261004-222427/summary.json']
out={}
for p in paths:
 try:out[p]=(root/p).read_text()
 except Exception as e:out[p]={'error':str(e)}
print(json.dumps(out))
'''
b64=base64.b64encode(code.encode()).decode()
r=subprocess.run(['ssh','hdacp1@176.0.250.88','python3 -c "import base64;exec(base64.b64decode(\''+b64+'\'))"'],capture_output=True,timeout=45)
(base/'coverage_server_details.json').write_bytes(r.stdout)
print('rc',r.returncode,'bytes',len(r.stdout))
d=json.loads(r.stdout)
for p,v in d.items():print('\n',p,'\n',str(v)[:12000])
