from pathlib import Path
import json,csv,statistics,collections,math,hashlib
P=Path('C:/Users/花喵/tmp/tfs_deep_review_20261018')
R=Path('C:/Users/花喵/tmp/tfs18/results/crosslayer-fusion-20261008')
d=json.loads((P/'coverage_oct07_raw.json').read_text(encoding='utf8'))
launch={}
for fam,runs in d.items():
 for run in runs:
  for f in (R/'runs'/run['run']/'launcher').glob('*/job_id.txt'):
   jid=f.read_text(encoding='utf8').strip().split(';')[0]
   cf=f.parent/'command.json'
   if cf.exists():
    cmd=json.loads(cf.read_text(encoding='utf8'))
    launch[jid]={'exclusive':'--exclusive' in cmd,'command':str(cf.relative_to(R))}
diag={'mycielskian19','reddit','roadNet-CA','amazon0601'}
result={'families':{},'contrasts':[],'csv_checks':[],'source_matches':[]}
def gm(xs):return math.exp(statistics.mean(map(math.log,xs)))
def contrast(fam,base,cand,cohort='diag',shape=None):
    pairs=collections.defaultdict(list)
    for run in d[fam]:
      for job in run['jobs']:
        part=job.get('environment.json',{}).get('SLURM_JOB_PARTITION')
        meta=launch.get(job['job'].rsplit('-',1)[-1])
        alloc=part+('_exclusive' if meta and meta['exclusive'] else '_shared' if meta else '_unknown')
        for packet in job['packets']:
          graph=packet['packet']
          if cohort=='diag' and graph not in diag:continue
          if cohort=='synthetic' and not graph.startswith('regular128'):continue
          if cohort=='real' and (graph.startswith(('regular','state_','window_','plan_'))):continue
          by=collections.defaultdict(dict)
          for m in packet['medians']:
            if shape and m['shape']!=shape:continue
            by[(m['kind'],m['shape'])][m['method']]=m['median']
          for (kind,sh),ms in by.items():
            if base not in ms or cand not in ms:continue
            pairs[(alloc,kind,sh)].append({'job':job['job'],'graph':graph,'base_ms':ms[base],'candidate_ms':ms[cand],'speedup':ms[base]/ms[cand]})
    for (alloc,kind,sh),rows in pairs.items():
      x={'family':fam,'base':base,'candidate':cand,'cohort':cohort,'allocation':alloc,'kind':kind,'shape':sh,'n':len(rows),'gm':gm([r['speedup'] for r in rows]),'wins':sum(r['speedup']>1 for r in rows),'rows':rows}
      result['contrasts'].append(x)
      print(fam,cohort,alloc,kind,sh,base,'/',cand,'n',len(rows),'gm',round(x['gm'],6),'wins',x['wins'])
for fam,runs in d.items():
  result['families'][fam]={'runs':len(runs),'jobs':sum(len(r['jobs']) for r in runs),'packets':sum(len(j['packets']) for r in runs for j in r['jobs']),'raw_timing_rows':sum(len(p['times']) for r in runs for j in r['jobs'] for p in j['packets']),'gate_failures':sum(len(p['failed_gates']) for r in runs for j in r['jobs'] for p in j['packets'])}
  for run in runs:
    exps=list((R/'experiments').glob(fam.replace('-','_')+'_*'))
    if exps:
      for src in (R/'runs'/run['run']/'source_snapshot').glob('*'):
        exp=exps[0]/src.name
        if exp.is_file() and src.is_file():
          result['source_matches'].append({'family':fam,'run':run['run'],'file':src.name,'matches_current_experiment':src.read_bytes()==exp.read_bytes()})
    for job in run['jobs']:
      for packet in job['packets']:
        raw=packet['times']
        for f in (R/packet['path']).parent.glob('*_time.csv'):
          if 'stage' in f.name:continue
          rows=list(csv.DictReader(f.open(encoding='utf-8-sig',newline='')))
          check={'path':str(f.relative_to(R)),'csv_rows':len(rows),'raw_rows':len(raw),'unmatched':0}
          # Complete graph-local primary timing projection (CSV may add empty fields).
          key=lambda x:(x.get('graph'),x.get('method'),x.get('kind'),x.get('shape') or None,x.get('repeat'),float(x.get('ms',0)))
          rr=collections.Counter(key(x) for x in raw)
          for row in rows:
            k=key(row)
            if rr[k]<=0:check['unmatched']+=1
            else:rr[k]-=1
          check['unrepresented_raw']=sum(rr.values())
          result['csv_checks'].append(check)
contrast('state-reuse','p0_degree','pack_epi_degree','real')
contrast('state-reuse','pack_epi_degree','pair_i_degree','real')
contrast('state-reuse','pack_epi_degree','pair_s_degree','real')
contrast('pair-plan','pack_epi_degree','opt_exact_s_degree','real')
contrast('pair-plan','pack_epi_degree','opt_dyn_s_degree','real')
contrast('pair-plan','adj_scalar_degree','rand_scalar_degree','synthetic')
contrast('pair-order-control','slot_adj_scalar','slot_pairs_scalar','synthetic')
contrast('pair-order-control','slot_adj_scalar','slot_rand_scalar','synthetic')
contrast('order-share-factorial','pack_epi_degree','slot_pairs_s1_exact_s')
contrast('access-prefetch','pack_epi_degree','s1ExactSP8')
contrast('access-prefetch','adjScalarP1','adjScalarP8')
contrast('event-trace','pack_epi_degree','trace_s_rep')
contrast('event-trace','pack_epi_qguard','trace_s_rep')
contrast('event-trace','dyn_s','trace_s_cached')
contrast('grouping-balance','s64_mfull_degree_fast','s64_mfull_qguard_fast','real')
contrast('order-balance','A_A_degree','Pall_A_degree','real','128_128_128')
contrast('order-balance','A_A_degree','Pall_A_degree','real','128_32_32')
(P/'coverage_oct07_stats.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf8')
print('CSV',len(result['csv_checks']),sum(c['csv_rows'] for c in result['csv_checks']),'unmatched',sum(c['unmatched'] for c in result['csv_checks']),'unrepresented',sum(c['unrepresented_raw'] for c in result['csv_checks']))
print('current exp differs from snapshot:',[x for x in result['source_matches'] if not x['matches_current_experiment']])
