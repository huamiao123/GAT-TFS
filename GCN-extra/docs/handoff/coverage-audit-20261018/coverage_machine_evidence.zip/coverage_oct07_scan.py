from pathlib import Path
import json,re,collections,statistics,hashlib
ROOT=Path('C:/Users/花喵/tmp/tfs18/results/crosslayer-fusion-20261008')
OUT=Path('C:/Users/花喵/tmp/tfs_deep_review_20261018')
families=['grouping-balance','order-balance','state-reuse','pair-plan','pair-order-control','order-share-factorial','access-prefetch','event-trace']
result={}
for fam in families:
    runs=[]
    for run in sorted((ROOT/'runs').glob(fam+'-*')):
        r={'run':run.name,'build_logs':[], 'jobs':[]}
        for f in (run/'build').glob('*'):
            if f.suffix in ['.log','.txt'] and f.stat().st_size<30000:
                r['build_logs'].append({'name':f.name,'size':f.stat().st_size,'tail':f.read_text(encoding='utf8',errors='replace')[-1200:]})
        for job in sorted((run/'logs').glob('*')):
            if not job.is_dir():continue
            j={'job':job.name,'packets':[],'source_snapshots':None}
            for n in ['environment.json','completion.json','suite_status.json','graph_list.json','exit_status.txt']:
                f=job/n
                if f.exists():
                    t=f.read_text(encoding='utf8',errors='replace')
                    try:j[n]=json.loads(t)
                    except:j[n]=t
            for f in sorted(job.glob('*/methods.log')):
                d={'packet':f.parent.name,'path':str(f.relative_to(ROOT)),'tags':{},'failed_gates':[], 'times':[], 'medians':[], 'structures':[]}
                tags=collections.Counter(); times=collections.defaultdict(list)
                for ln,line in enumerate(f.read_text(encoding='utf8',errors='replace').splitlines(),1):
                    tag=line.split(' ',1)[0];tags[tag]+=1
                    fields=dict(re.findall(r'(\w+)=([^\s]+)',line))
                    if fields.get('pass') in ['0','false','FAIL'] or ('GATE' in tag and fields.get('status')=='FAIL'):
                        d['failed_gates'].append({'line':ln,'text':line})
                    if tag.endswith('_TIME') and 'ms' in fields and 'method' in fields and not tag.endswith('STAGE_TIME'):
                        fields['tag']=tag;d['times'].append(fields)
                        times[(fields.get('graph'),fields.get('method'),fields.get('kind'),fields.get('shape'))].append(float(fields['ms']))
                    if any(s in tag for s in ['STRUCTURE','OPPORTUNITY','PLAN','COMPLETE','CONFIG','REJECT_AUDIT']) and len(line)<3000:
                        d['structures'].append({'tag':tag,**fields})
                d['tags']=dict(tags)
                for key,vals in times.items():
                    d['medians'].append(dict(zip(['graph','method','kind','shape'],key),n=len(vals),median=statistics.median(vals),minimum=min(vals),maximum=max(vals)))
                j['packets'].append(d)
            r['jobs'].append(j)
        runs.append(r)
    result[fam]=runs
(OUT/'coverage_oct07_raw.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf8')
for fam,runs in result.items():
    print(fam)
    for run in runs:
        print(' ',run['run'],'jobs',len(run['jobs']))
        for j in run['jobs']:
            np=len(j['packets']);nt=sum(len(p['times']) for p in j['packets']);ng=sum(len(p['failed_gates']) for p in j['packets'])
            print('  ',j['job'],'packets',np,'time_rows',nt,'failed_gate_rows',ng,'exit',str(j.get('exit_status.txt','?')).strip(),'graphs',','.join(p['packet'] for p in j['packets']))
