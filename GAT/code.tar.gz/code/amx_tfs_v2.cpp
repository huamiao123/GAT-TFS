/*
 * amx_tfs_v2.cpp — TFS Fusion V2: Full-K Gather + 4C Tile
 *
 * Key changes vs V1:
 *   1. Neighbor-outer loop: each neighbor gathered ONCE per obp (full 128-dim)
 *   2. 4 C tiles -> 2 obp passes (was 2C, 4 passes)
 *   3. Gather per neighbor: 2x total (was 16x), 8x reduction
 *   4. KB-inner loop hits L1 for Hbuf re-reads
 *   5. 7/8 tiles used: C0 C1 C2 C3 A B0 B1
 */

#include <cstdint>
#include <cstring>
#include <cstdlib>
#include <cstdio>
#include <cmath>
#include <ctime>
#include <immintrin.h>
#include <sys/syscall.h>
#include <unistd.h>
#include <omp.h>

#define K_IN   128
#define K_OUT  128
#define KB     4
#define NB     8
#define TR     16
#define NP     2

#define TC0  0
#define TC1  1
#define TC2  2
#define TC3  3
#define TA   4
#define TB0  5
#define TB1  6

struct __attribute__((aligned(64))) tilecfg_t {
    uint8_t  palette;
    uint8_t  start_row;
    uint8_t  reserved[14];
    uint16_t colsb[16];
    uint8_t  rows[16];
};

static void setup_tilecfg(tilecfg_t *cfg)
{
    memset(cfg, 0, sizeof(*cfg));
    cfg->palette = 1;
    for (int t = 0; t < 7; t++) {
        cfg->rows[t]  = TR;
        cfg->colsb[t] = 64;
    }
}

static inline uint16_t f32_to_bf16(float f)
{
    uint32_t u;
    memcpy(&u, &f, 4);
    return (uint16_t)(u >> 16);
}

static inline float bf16_to_f32(uint16_t b)
{
    uint32_t u = (uint32_t)b << 16;
    float f;
    memcpy(&f, &u, 4);
    return f;
}

static void make_W_vnni(const float *W, uint16_t *Wv)
{
    for (int kb = 0; kb < KB; kb++) {
        for (int ob = 0; ob < NB; ob++) {
            for (int kp = 0; kp < 16; kp++) {
                for (int n = 0; n < 16; n++) {
                    int k0  = kb * 32 + kp * 2;
                    int k1  = k0 + 1;
                    int col = ob * 16 + n;
                    uint16_t v0 = f32_to_bf16(W[k0 * K_OUT + col]);
                    uint16_t v1 = f32_to_bf16(W[k1 * K_OUT + col]);
                    int base = ((kb * NB + ob) * 16 + kp) * 32 + n * 2;
                    memcpy(&Wv[base + 0], &v0, 2);
                    memcpy(&Wv[base + 1], &v1, 2);
                }
            }
        }
    }
}

static void convert_H_bf16(const float *H, uint16_t *Hb, int N)
{
    #pragma omp parallel for schedule(static)
    for (int i = 0; i < N; i++) {
        for (int k = 0; k < K_IN; k++) {
            Hb[(size_t)i * K_IN + k] = f32_to_bf16(H[(size_t)i * K_IN + k]);
        }
    }
}

/* ================================================================
 * TFS V2 Kernel
 * ================================================================ */
static void tfs_v2(
    const uint32_t *indptr,
    const uint32_t *indices,
    const uint16_t *Hb,
    const uint16_t *Wv,
    float          *C,
    int N, int R)
{
    memset(C, 0, (size_t)N * K_OUT * sizeof(float));

    #pragma omp parallel
    {
        if (syscall(SYS_arch_prctl, 0x1023, 18) != 0) {
            perror("arch_prctl"); exit(1);
        }
        tilecfg_t cfg;
        setup_tilecfg(&cfg);
        _tile_loadconfig(&cfg);

        uint16_t Hbuf[TR * K_IN]  __attribute__((aligned(64)));
        float    Ctmp[TR * 16]    __attribute__((aligned(64)));

        #pragma omp for schedule(dynamic, 1) nowait
        for (int rg = 0; rg < N; rg += R) {
            int rg_end = (rg + R < N) ? (rg + R) : N;

            for (int i = rg; i < rg_end; i += TR) {
                int batch = ((i + TR) <= rg_end) ? TR : (rg_end - i);

                int max_deg = 0;
                for (int n = 0; n < batch; n++) {
                    int deg = (int)(indptr[i+n+1] - indptr[i+n]);
                    if (deg > max_deg) max_deg = deg;
                }

                for (int obp = 0; obp < NP; obp++) {
                    _tile_zero(TC0);
                    _tile_zero(TC1);
                    _tile_zero(TC2);
                    _tile_zero(TC3);

                    for (int s = 0; s < max_deg; s++) {
                        memset(Hbuf, 0, TR * K_IN * sizeof(uint16_t));
                        for (int n = 0; n < batch; n++) {
                            uint32_t base = indptr[i + n];
                            uint32_t deg  = indptr[i + n + 1] - base;
                            if ((uint32_t)s < deg) {
                                uint32_t j = indices[base + s];
                                memcpy(&Hbuf[n * K_IN],
                                       &Hb[(size_t)j * K_IN],
                                       K_IN * sizeof(uint16_t));
                            }
                        }

                        for (int kb = 0; kb < KB; kb++) {
                            _tile_loadd(TA,
                                        (const uint8_t*)Hbuf + kb * 64,
                                        K_IN * 2);

                            int ob0 = obp * 4;
                            const uint16_t *Wb = Wv;

                            #define WV_OFF(kb_, ob_) \
                                (((kb_) * NB + (ob_)) * 16 * 32)

                            _tile_loadd(TB0, &Wb[WV_OFF(kb, ob0+0)], 64);
                            _tile_loadd(TB1, &Wb[WV_OFF(kb, ob0+1)], 64);
                            _tile_dpbf16ps(TC0, TA, TB0);
                            _tile_dpbf16ps(TC1, TA, TB1);

                            _tile_loadd(TB0, &Wb[WV_OFF(kb, ob0+2)], 64);
                            _tile_loadd(TB1, &Wb[WV_OFF(kb, ob0+3)], 64);
                            _tile_dpbf16ps(TC2, TA, TB0);
                            _tile_dpbf16ps(TC3, TA, TB1);

                            #undef WV_OFF
                        }
                    }

                    int col = obp * 64;

                    _tile_stored(TC0, Ctmp, 64);
                    for (int n = 0; n < batch; n++)
                        memcpy(&C[(size_t)(i+n)*K_OUT + col +  0],
                               &Ctmp[n*16], 64);

                    _tile_stored(TC1, Ctmp, 64);
                    for (int n = 0; n < batch; n++)
                        memcpy(&C[(size_t)(i+n)*K_OUT + col + 16],
                               &Ctmp[n*16], 64);

                    _tile_stored(TC2, Ctmp, 64);
                    for (int n = 0; n < batch; n++)
                        memcpy(&C[(size_t)(i+n)*K_OUT + col + 32],
                               &Ctmp[n*16], 64);

                    _tile_stored(TC3, Ctmp, 64);
                    for (int n = 0; n < batch; n++)
                        memcpy(&C[(size_t)(i+n)*K_OUT + col + 48],
                               &Ctmp[n*16], 64);
                }
            }
        }
        _tile_release();
    }
}

/* ================================================================
 * Reference two-step (scalar)
 * ================================================================ */
static void ref_twostep(
    const uint32_t *indptr, const uint32_t *indices,
    const uint16_t *Hb, const float *W,
    float *C_ref, int N)
{
    float *Z = (float*)calloc((size_t)N * K_IN, sizeof(float));
    if (!Z) { fprintf(stderr, "OOM Z\n"); exit(1); }

    for (int i = 0; i < N; i++) {
        for (uint32_t p = indptr[i]; p < indptr[i+1]; p++) {
            uint32_t j = indices[p];
            for (int k = 0; k < K_IN; k++)
                Z[(size_t)i*K_IN+k] += bf16_to_f32(Hb[(size_t)j*K_IN+k]);
        }
    }
    for (int i = 0; i < N; i++) {
        for (int n = 0; n < K_OUT; n++) {
            float sum = 0.0f;
            for (int k = 0; k < K_IN; k++)
                sum += Z[(size_t)i*K_IN+k] * W[k*K_OUT+n];
            C_ref[(size_t)i*K_OUT+n] = sum;
        }
    }
    free(Z);
}

/* ================================================================
 * CSR loading -- .csrbin format
 *
 * Header (36 bytes):
 *   [0:8]   uint64  reserved (0)
 *   [8:12]  uint32  type (2 = general)
 *   [12:20] uint64  nrows
 *   [20:28] uint64  ncols
 *   [28:36] uint64  nnz
 * Data:
 *   uint32 indptr[nrows+1]
 *   uint32 indices[nnz]
 *   float32 values[nnz]   (ignored)
 * ================================================================ */
struct csr_t {
    uint32_t *indptr;
    uint32_t *indices;
    int N;
    uint32_t nnz;
};

static csr_t load_csrbin(const char *path)
{
    FILE *f = fopen(path, "rb");
    if (!f) { fprintf(stderr, "Cannot open %s\n", path); exit(1); }

    uint8_t hdr[36];
    if (fread(hdr, 1, 36, f) != 36) {
        fprintf(stderr, "Failed to read header from %s\n", path); exit(1);
    }

    uint32_t type;
    uint64_t nrows64, ncols64, nnz64;
    memcpy(&type,    &hdr[8],  4);
    memcpy(&nrows64, &hdr[12], 8);
    memcpy(&ncols64, &hdr[20], 8);
    memcpy(&nnz64,   &hdr[28], 8);

    int N = (int)nrows64;
    uint32_t nnz = (uint32_t)nnz64;

    printf("  csrbin: type=%u  N=%d  ncols=%llu  NNZ=%u\n",
           type, N, (unsigned long long)ncols64, nnz);

    uint32_t *indptr = (uint32_t*)malloc((size_t)(N+1) * sizeof(uint32_t));
    if (!indptr) { fprintf(stderr, "OOM indptr\n"); exit(1); }
    if (fread(indptr, sizeof(uint32_t), N+1, f) != (size_t)(N+1)) {
        fprintf(stderr, "Failed to read indptr\n"); exit(1);
    }

    uint32_t *indices = (uint32_t*)malloc((size_t)nnz * sizeof(uint32_t));
    if (!indices) { fprintf(stderr, "OOM indices\n"); exit(1); }
    if (fread(indices, sizeof(uint32_t), nnz, f) != (size_t)nnz) {
        fprintf(stderr, "Failed to read indices\n"); exit(1);
    }

    fclose(f);

    if (indptr[N] != nnz) {
        fprintf(stderr, "WARNING: indptr[N]=%u != header nnz=%u\n",
                indptr[N], nnz);
    }

    csr_t csr;
    csr.indptr  = indptr;
    csr.indices = indices;
    csr.N       = N;
    csr.nnz     = nnz;
    return csr;
}

/* ================================================================ */
static void selftest()
{
    printf("=== Self-test (N=256, avg_deg=8) ===\n");
    const int N = 256, avg_deg = 8;

    srand(42);
    uint32_t *indptr = (uint32_t*)malloc((N+1)*sizeof(uint32_t));
    indptr[0] = 0;
    for (int i = 0; i < N; i++) {
        int deg = avg_deg/2 + rand()%(avg_deg+1);
        indptr[i+1] = indptr[i] + deg;
    }
    uint32_t nnz = indptr[N];
    uint32_t *indices = (uint32_t*)malloc(nnz*sizeof(uint32_t));
    for (uint32_t p = 0; p < nnz; p++) indices[p] = rand() % N;

    float *H = (float*)malloc((size_t)N*K_IN*sizeof(float));
    float *W = (float*)malloc((size_t)K_IN*K_OUT*sizeof(float));
    for (int i = 0; i < N*K_IN;  i++) H[i] = 0.01f*((rand()%200)-100);
    for (int i = 0; i < K_IN*K_OUT; i++) W[i] = 0.01f*((rand()%200)-100);

    uint16_t *Hb = (uint16_t*)aligned_alloc(64,(size_t)N*K_IN*2);
    uint16_t *Wv = (uint16_t*)aligned_alloc(64,(size_t)KB*NB*16*32*2);
    convert_H_bf16(H, Hb, N);
    make_W_vnni(W, Wv);

    float *C_tfs = (float*)calloc((size_t)N*K_OUT, sizeof(float));
    tfs_v2(indptr, indices, Hb, Wv, C_tfs, N, 64);

    float *C_ref = (float*)calloc((size_t)N*K_OUT, sizeof(float));
    ref_twostep(indptr, indices, Hb, W, C_ref, N);

    double max_d=0, max_r=0;
    for (size_t i = 0; i < (size_t)N*K_OUT; i++) {
        double d = fabs((double)C_tfs[i]-(double)C_ref[i]);
        double r = fabs((double)C_ref[i]);
        if (d>max_d) max_d=d;
        if (r>max_r) max_r=r;
    }
    double rel = (max_r>0) ? max_d/max_r : 0;
    printf("  max|diff|=%.6e  max|ref|=%.6e  rel_err=%.6f\n", max_d, max_r, rel);
    printf("  %s\n", (rel<0.02)?"PASS":"FAIL");
    printf("  TFS[0:8] =");
    for(int i=0;i<8;i++) printf(" %.4f",C_tfs[i]);
    printf("\n  Ref[0:8] =");
    for(int i=0;i<8;i++) printf(" %.4f",C_ref[i]);
    printf("\n");

    free(indptr);free(indices);free(H);free(W);
    free(Hb);free(Wv);free(C_tfs);free(C_ref);
}

/* ================================================================ */
static void benchmark(const char *dir, const char *name, int R)
{
    char path[512];
    snprintf(path, sizeof(path), "%s/%s/%s.csrbin", dir, name, name);
    printf("Loading: %s\n", path);
    csr_t csr = load_csrbin(path);
    int N = csr.N;
    uint32_t nnz = csr.nnz;
    uint32_t *indptr  = csr.indptr;
    uint32_t *indices = csr.indices;

    double avg_deg = (double)nnz/N;
    printf("Matrix: %s  N=%d  NNZ=%u  avg_deg=%.1f  R=%d\n",
           name, N, nnz, avg_deg, R);

    srand(12345);
    float *H = (float*)malloc((size_t)N*K_IN*sizeof(float));
    float *W = (float*)malloc((size_t)K_IN*K_OUT*sizeof(float));
    for(size_t i=0;i<(size_t)N*K_IN;i++) H[i]=0.01f*((rand()%200)-100);
    for(int i=0;i<K_IN*K_OUT;i++) W[i]=0.01f*((rand()%200)-100);

    uint16_t *Hb = (uint16_t*)aligned_alloc(64,(size_t)N*K_IN*2);
    uint16_t *Wv = (uint16_t*)aligned_alloc(64,(size_t)KB*NB*16*32*2);
    convert_H_bf16(H, Hb, N);
    make_W_vnni(W, Wv);
    float *C = (float*)calloc((size_t)N*K_OUT, sizeof(float));

    tfs_v2(indptr, indices, Hb, Wv, C, N, R);

    double best = 1e30;
    for (int run = 0; run < 5; run++) {
        double t0 = omp_get_wtime();
        tfs_v2(indptr, indices, Hb, Wv, C, N, R);
        double t1 = omp_get_wtime();
        double ms = (t1-t0)*1000.0;
        printf("  run %d: %.2f ms\n", run, ms);
        if (ms<best) best=ms;
    }
    printf("  BEST: %.2f ms  (R=%d)\n\n", best, R);

    int ck = (N<512)?N:512;
    float *C_ref = (float*)calloc((size_t)ck*K_OUT,sizeof(float));
    ref_twostep(indptr, indices, Hb, W, C_ref, ck);
    double md=0,mr=0;
    for(size_t i=0;i<(size_t)ck*K_OUT;i++){
        double d=fabs((double)C[i]-(double)C_ref[i]);
        double r=fabs((double)C_ref[i]);
        if(d>md)md=d; if(r>mr)mr=r;
    }
    double rel=(mr>0)?md/mr:0;
    printf("  Correctness (first %d rows): rel_err=%.6f %s\n",
           ck, rel, (rel<0.02)?"PASS":"FAIL");

    free(indptr);free(indices);free(H);free(W);
    free(Hb);free(Wv);free(C);free(C_ref);
}

/* ================================================================ */
int main(int argc, char **argv)
{
    printf("TFS Fusion V2 -- Full-K Gather + 4C Tile\n");
    printf("Threads: %d\n\n", omp_get_max_threads());

    if (argc>=2 && strcmp(argv[1],"--selftest")==0) {
        selftest();
        return 0;
    }
    if (argc<3) {
        fprintf(stderr,
            "Usage:\n"
            "  %s --selftest\n"
            "  %s <data_dir> <matrix_name> [R=64]\n"
            "  %s <data_dir> <matrix_name> 0    # test R=64,128,256\n"
            "\nExpects: <dir>/<name>/<name>.csrbin\n",
            argv[0],argv[0],argv[0]);
        return 1;
    }

    const char *dir=argv[1], *name=argv[2];
    int R = (argc>=4) ? atoi(argv[3]) : 64;

    if (R==0) {
        int Rs[]={64,128,256};
        for(int ri=0;ri<3;ri++) benchmark(dir,name,Rs[ri]);
    } else {
        benchmark(dir,name,R);
    }
    return 0;
}
